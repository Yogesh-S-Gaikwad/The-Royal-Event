<!DOCTYPE html>
<html lang="en">
<head>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <title>FAQ |Frequently Asked Questions On Event Management Companies</title>
<meta name="description" content="Bamboo Events is an Event Management Company in Coimbatore that assists you with answering events management/planner FAQ  questions." />

 <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->

<!-- favicon icon -->
<link rel="shortcut icon" href="images/favicon.png" />
<!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<!-- animate -->
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<!-- owl-carousel -->
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<!-- fontawesome -->
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<!-- themify -->
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<!-- flaticon -->
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<!-- REVOLUTION LAYERS STYLES -->
<link rel="stylesheet" type="text/css" href="revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="revolution/css/settings.css">

<!-- prettyphoto -->
<link rel="stylesheet" type="text/css"             
href="css/prettyPhoto.css">

<!-- shortcodes -->
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>

<!-- main -->
<link rel="stylesheet" type="text/css" href="css/main.css"/>

<!-- responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
</head>

<body>
    
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P6N5G4L"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    <!--page start-->

     <div class="page">
<header id="masthead" class="header ttm-header-style-classic">
            <!--topbar start-->
            <!--<div class="ttm-topbar-wrapper ttm-bgcolor-skincolor ttm-textcolor-white clearfix bg-white top-header">-->
            <!--    <div class="container">-->
            <!--        <div class="ttm-topbar-content">-->
            <!--            <div class="topbar-right text-left">-->
            <!--                <div class="ttm-social-links-wrapper list-inline" style="padding:0px;">-->
            <!--                    <ul class="social-icons">-->
            <!--                        <li><a href="#" class="fb"><i class="fa fa-facebook"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="tw"><i class="fa fa-twitter"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="pi"><i class="fa fa-pinterest"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="ln"><i class="fa fa-linkedin"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="in"><i class="fa fa-instagram"></i></a>-->
            <!--                        </li>-->
            <!--                    </ul>-->
            <!--                </div>-->
            <!--                <ul class="top-contact float-right">-->
            <!--                    <a href="#" class="float-left mail-ixon"><i class="fa fa-envelope"></i>&nbsp; info@bambooevents.com</a>-->
            <!--                    <li class="list-inline-item"><strong><a href="tel:+91 99949 24984"><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                 <li class="list-inline-item"><a href="tel:+91 99949 24984"><strong><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                </ul>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            <!--topbar end-->
            <!-- ttm-header-wrap -->
            <div id="ttm-header-wrap">
                <!-- ttm-stickable-header-w -->
                <div id="ttm-stickable-header-w" class="ttm-stickable-header-w ttm-bgcolor-white clearfix bg-transparent">
                    <div id="site-header-menu" class="site-header-menu">
                        <div class="site-header-menu-inner ttm-stickable-header">
                              <div class="container">
                                <div class="site-header-main">
                                    <!-- site-branding -->
                                    <div class="site-branding">
                                        <a class="home-link display-prop" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo-white.png" alt="logo" width="218" height="100">
                                        </a>
                                        <a class="home-link display-prop1" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo1.webp" alt="logo" width="218" height="100">
                                        </a>
                                    </div><!-- site-branding end -->
                                    <!--site-navigation -->
                                    <div id="site-navigation" class="site-navigation">
                                        <!-- header-icins -->
                                        <div class="ttm-menu-toggle">
                                            <input type="checkbox" id="menu-toggle-form" />
                                            <label for="menu-toggle-form" class="ttm-menu-toggle-block">
                                                <span class="toggle-block toggle-blocks-1"></span>
                                                <span class="toggle-block toggle-blocks-2"></span>
                                                <span class="toggle-block toggle-blocks-3"></span>
                                            </label>
                                        </div>
                                        <nav id="menu" class="menu">
                                            <ul class="dropdown">
                                                <li class=""><a href="index.php">Home</a></li>
                                                <li class=""><a href="top-event-management-companies.php">About Us</a></li>
                                                <li class=""><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                                <li class=""><a href="top-event-management-gallery.php">Gallery</a></li>
                                                <li class="active"><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                                <li class=""><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                                <li class=""><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <!--site-navigation end-->
                                </div>
                            </div>
                        </div>
                    </div><!--ttm-header-wrap end -->
                    
                </div>
            </div><!-- ttm-header-wrap END -->
                    </header>
        <!--header end-->             <!--page-title-start-->
        <div class="ttm-page-title-row text-center">
            <div class="section-overlay"></div>
            <div class="title-box text-center">
                <div class="container">
                    <div class="page-title-heading">
                        <h1 class="title">Frequently Asked Questions</h1>
                    </div>
                    <div class="breadcrumb-wrapper">
                        <div class="container">
                            <span><a title="Homepage" href="index.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a></span>
                            <span class="ttm-bread-sep ttm-textcolor-white"> &nbsp; ⁄ &nbsp;</span>
                            <span class="ttm-textcolor-white">FAQ</span>
                        </div>
                    </div>
                </div>  
            </div>
        </div>
        <!--page-title-end-->


        <!--syte-main start-->
        <div class="site-main">
            <!--intro-section-->
            <section class="ttm-row break-991-colum ttm-bgcolor-white clearfix faq-intro-section">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-12">
                            <div class="mb-35">
                                <h2 class="ttm-textcolor-skincolor">FAQ About Event Management Company</h2>
                               <!--  <p>Below you’ll find answers to some of the most frequently asked questions at PresentUp. We are constantly adding most asked question to this page so if you have a question and don’t see your answer, don’t hesitate to email us at <a href="#">info@example.com</a></p> -->
                            </div>
                            <!-- wrap-acadion -->
                            <div class="wrap-acadion">
                                <div class="accordion">
                                    <!-- toggle -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">What is Event Planning?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">The concept of planning and executing an organised event, such as a conference, business event, corporate activity, or special event, is identified as event planning. From determining the event's intent to identifying target audience, choosing a location, managing catering, promotions, and incorporating technological strategies to post-event surveys and reports.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                   <!-- toggle -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">What is Event Management?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">The true nature of an event management solution are similar to those of a monitor: while the hands shift around the monarch, the gears inside drive the action. On the day of the event, an event planner is in charge of all the behind-the-scenes details, such as ensuring that the food is served on time that the entertainment is available, that the visitors will find a parking space, and that all of the guests are taken care of.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">Why Do We Need an Event Planner?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">The primary objective and responsibility of an event planner is to assist you in being focused and organised. We're here to keep you on track, recommend trustworthy suppliers, include a wealth of services, bargain on your behalf, and see that your vision is realised. If you hire us for services, we will not only schedule your case, but we will also respond quickly to any potential surprises that might arise.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">What Separates You From Other Event Planners?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">It all gets close to it all: we'll manage your event as though it were our own. We'll be there to help you visualize your goals and find out what your choices are. We will provide you with end to end service and will be there to ensure a successful event, unlike larger event planning services.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">What Types of Events Does Only in My Dreams Plan?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">We are happy to help you organize any type of event. From your dream wedding with hundreds of guests to corporate/non-profit meetings and all in between, we will help. We would turn your vision a reality no matter what your desires or budget.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">How Often Will We Meet?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">This is ideally answered at our initial meeting. We will build a schedule until we know what you want your event to be like. We'll come up with an estimation for the total number of gatherings and time needed during the meeting to help you stay on track with your budget.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">How Do You Select Your Event Vendors?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">Along with our considerable experience with event organising and several other activities, we have developed strong relationships with a number of high-quality vendors in Coimbatore. A big part of our work is reviewing each vendor and making sure they're the best in their sectors and have all of the necessary approvals. We really like to partner with suppliers that are enjoyable to work with, as we think it helps the whole planning process go more seamlessly.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                      <!-- toggle -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">Do I Have to Go Through Your Vendors If I Hire You as My Planner/Designer?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">No, is the simple answer. We have worked tirelessly to build those partnerships, and we can guarantee the level of service offered by the vendors we recommend. We are, however, more than willing to collaborate with any vendors you choose.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <!-- toggle -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">Do you charge separately for your various event services?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">A few of our services are included in cost, while others may be charged separately. Call us just to meet with one of our event planners to get an estimate of how much the event would cost. They will provide you with a free estimate depending on your specific requirements.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">Do You Provide Last Minute Event Management Services?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">Yes, is the simple answer? we are entirely comfortable functioning in a high-stress, last-minute environment, so don't hesitate to contact us if you need to organize a last-minute event. We'll let you know if it's not practical, but our motto is that "there's always a way."</p>
                                        </div>
                                    </div><!-- toggle end -->
                                    <div class="toggle ttm-style-classic ttm-toggle-title ttm-toggle-title-bgcolor-grey">
                                        <h4 class="toggle-title">Can I Just Get Your Help With One Aspect Of My Event?</h4>
                                        <div class="toggle-content">
                                            <p style="text-align:justify">Well, truly! We can manage all types of an event or include only the facilities you need for a specific event. Venue finding, onsite event management, event registration, event managed services, team bonding events, executive training sessions, and several other resources are available.</p>
                                        </div>
                                    </div><!-- toggle end -->
                                  
                                    
                                </div>                   
                            </div><!-- wrap-acadion end-->
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="padding-12 box-shadow">
                                <!-- section title -->
                                <div class="section-title clearfix mb-30">
                                    <h3 class="title">Get The Party Started</h3>
                                    <p>Organise Your Next Event with the Experts</p>
                                </div><!-- section title end -->
                                <form id="contactform" class="row contactform wrap-form clearfix" method="post" action="#">
                                    <label class="col-md-6">
                                        <i class="ti ti-user"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="name" type="text" value="" placeholder="Name:*" required="required"></span>
                                    </label>
                                    <label class="col-md-6">
                                        <i class="ti ti-email"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="email" type="text" value="" placeholder="Email-id:*" required="required"></span>
                                    </label>
                                    <label class="col-md-6">
                                        <i class="ti ti-location-pin"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="venue" type="text" value="" placeholder="Location" required="required"></span>
                                    </label>
                                    <label class="col-md-6">
                                        <i class="ti ti-mobile"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="phone" type="text" value="" placeholder="Mobile Number:*" required="required"></span>
                                    </label>
                                     
                                    
                                    <label class="col-md-12">
                                        <i class="ti ti-comment"></i>
                                        <span class="ttm-form-control"><textarea class="text-area" name="message" rows="8" placeholder="Ask Your Question Here" required="required"></textarea></span>
                                    </label>
                                    <input name="contactform" type="submit" value="Make a Reservation" class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-20" id="submit" title="Make a Reservation">
                               </form>
                            </div>
                        </div>
                    </div><!-- row end -->
                </div>
            </section>
            <!-- intro-section end -->
           
        </div><!-- site-main end --> 
       <footer class="footer widget-footer bg-img11 ttm-bgcolor-black ttm-bg ttm-bgimage-yes clearfix">
            <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
            <div class="second-footer">
                <div class="container">
                    <div class="second-footer-inner">
                        <div class="row">
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">Quick Links </h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="top-event-management-companies.php">Why Us</a></li>
                                        <li><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                        <li><a href="top-event-management-gallery.php">Gallery</a></li>
                                        <li><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                        <li><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                        <li><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="engagement-planner-coimbatore.php">Engagement</a></li>
                                        <li><a href="wedding-planner-coimbatore-india.php">Wedding Planner</a></li>
                                        <li><a href="top-best-destination-wedding-planners.php">Destination Wedding</a></li>
                                        <li><a href="corporate-event-management-companies.php">Corporate Events</a></li>
                                        <li><a href="product-launch-event-organizers-chennai.php">Product Launch Events</a></li>
                                        <li><a href="company-award-ceremony-event-planner.php">Company Award Ceremony</a></li>
                                        <li><a href="virtual-online-event-management-organizers.php">Virtual Event Planner</a></li>
                                        <li><a href="corporate-social-event-planner-india.php">Corporate Social Events</a></li>
                                        <li><a href="exhibition-stall-design-fabricators-services.php">Exhibition Stall</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix ">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="birthday-party-event-management.php">Birthday Party</a></li>
                                        <li><a href="housewarmig-functions-organizer.php">Housewarming</a></li>
                                        <li><a href="baby-naming-ceremony-events.php">Baby Naming Ceremony</a></li>
                                        <li><a href="puberty-event-function-organizer.php">Puberty Function</a></li>
                                        <li><a href="bangle-ceremony-event-valaikappu-function.php">Bangle Ceremony</a></li>
                                        <li><a href="sangeet-mehendi-ceremony-coimbatore.php">Sangeet & Mehendi</a></li>
                                        <li><a href="wedding-anniversary-event-planner.php">Anniversary</a></li>
                                        <li><a href="school-college-alumni-event-planners.php">College/School Alumni</a></li>
                                    </ul>
                                    <!--<h4 class="widget-title">Frequent Questions</h4>
                                    <ul class="widget-text">
                                        <li><a href="#">How Can I Set An Event? </a></li>
                                        <li><a href="#">What Venues Do You Use? </a></li>
                                        <li><a href="#">Event Catalogue </a></li>
                                        <li><a href="#">Shipping & Delivery </a></li>
                                        <li><a href="#">What's your dream job? </a></li>
                                    </ul>-->
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix">
                                    <h4 class="widget-title">Contact Us</h4>
                                    <ul class="widget-contact">
                                        <!--<li><i class="fa fa-map-marker"></i>No.45A, Kalluri Nagar,<br>Near Peelamedu Fire Station,<br>Periyar Nagar,<br>Masakalipalayam,<br>Peelamedu,<br>Coimbatore-641004.</li>-->
                                        <li><i class="fa fa-map-marker"></i>No.2, Ground floor,<br>D.J.Nagar,Hopescollage,<br>Near Water Tank,<br>Coimbatore-641 004.</li>
                                        <li><i class="fa fa-envelope-o"></i><a href="mailto:enquiry@bambooevents.co.in">enquiry@bambooevents.co.in</a></li>
                                        <li><a href="tel:+919994924984"><i class="fa fa-phone"></i>+91 99949 24984</li></a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-footer-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-xs-12 ttm-footer2-left">
                            <div class="company-info" style="color: #fff;">
                                  <P>Copyright © 2023 <span style="color: #b4cd29;">Bamboo Events Planning &amp; Decor</span>. All Rights Reserved. Designed By <a href="https://www.xcodefix.com/"target="_blank">Xcodefix</a></P>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xs-12 col-md-4 ttm-footer2-right">
                            <div class="ttm-social-link-wrapper list-inline" style="padding:2px;">
                                <ul class="social-icons">
                                    <ul class="social-icons">
                                    <li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li><a href="https://www.instagram.com/bambooevents_cbe/" class="in"><i class="fa fa-instagram"></i></a>
                                    </li>
                                    <li><a href="https://twitter.com/BambooDecors" class="tw"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    <li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" class="ln"><i class="fa fa-youtube-play"></i></a>
                                    </li>
                                    
                                </ul>
                                    <!--<li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a></li>-->
                                    <!--<li><a href="https://twitter.com/BambooDecors" target="_blank"><i class="fa fa-twitter"></i></a></li>-->
                                    <!--<li><a href="https://www.instagram.com/bambooevents_cbe/" target="_blank"><i class="fa fa-instagram"></i></a></li>-->
                                    <!--<li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" target="_blank"><i class="fa fa-youtube-play"></i></a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
</div>      <div class="side-icons">
    <div class="inner-side-icon">
        <a href="https://wa.me/+919994924984?text=I'm%20interested%20in%20your%20Bamboo%20Events%20Services" target="_blank"><i class="fa fa-whatsapp" style="font-size: 48px;"></i></a> 
    </div>
    <div class="inner-side-icon">
        <a href="tel:+919994924984"><i class="fa fa-phone" style="font-size: 48px;"></i></a>
    </div>
</div>    <!--back-to-top start-->
    <a id="totop" href="#top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!--back-to-top end-->
    <!-- Javascript -->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/jquery.easing.js"></script>    
    <script src="js/jquery-waypoints.js"></script>    
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/numinate.min6959.js?ver=4.9.3"></script>
    <script src="js/main.js"></script>
</body>
<!-- Mirrored from themetechmount.com/html/planwey/about-us.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Mar 2021 05:46:30 GMT -->
</html>