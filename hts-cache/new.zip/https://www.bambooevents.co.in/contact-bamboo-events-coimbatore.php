<!DOCTYPE html>
<html lang="en">
<head>
    
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->
 
 <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  "name": "Bamboo Events Planning and Decor",
  "image": "https://www.bambooevents.co.in/images/logo1.webp",
  "@id": "",
  "url": "https://www.bambooevents.co.in/contact-bamboo-events-coimbatore.php",
  "telephone": "+91 99949 24984",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "No.2, Ground floor, D.J.Nagar, Hopescollage,Near Water Tank,",
    "addressLocality": "Coimbatore",
    "postalCode": "641004",
    "addressCountry": "IN"
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": 11.018510281026481,
    "longitude": 77.01239729497802
  } ,
  "sameAs": [
    "https://www.facebook.com/bambooeventsindia/",
    "https://twitter.com/BambooDecors",
    "https://www.instagram.com/bambooevents_cbe/",
    "https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig"
  ] 
}
</script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <title>Bamboo Events Planning and Decor, Coimbatore, Tamilnadu, India</title>
<meta name="description" content="Bamboo Events Planning and Decor, Tamilnadu, one of Coimbatore's best event management companies, assists clients in making events memorable." />




<script src="https://www.google.com/recaptcha/api.js?render=6Lemt9wkAAAAAGTG3SbboRwpUfRVSXXKmDeIzd9M"></script>


 <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->

<!-- favicon icon -->
<link rel="shortcut icon" href="images/favicon.png" />
<!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<!-- animate -->
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<!-- owl-carousel -->
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<!-- fontawesome -->
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<!-- themify -->
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<!-- flaticon -->
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<!-- REVOLUTION LAYERS STYLES -->
<link rel="stylesheet" type="text/css" href="revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="revolution/css/settings.css">

<!-- prettyphoto -->
<link rel="stylesheet" type="text/css"             
href="css/prettyPhoto.css">

<!-- shortcodes -->
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>

<!-- main -->
<link rel="stylesheet" type="text/css" href="css/main.css"/>

<!-- responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
</head>

<body>
    
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P6N5G4L"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    <!--page start-->
  
     <div class="page">
<header id="masthead" class="header ttm-header-style-classic">
            <!--topbar start-->
            <!--<div class="ttm-topbar-wrapper ttm-bgcolor-skincolor ttm-textcolor-white clearfix bg-white top-header">-->
            <!--    <div class="container">-->
            <!--        <div class="ttm-topbar-content">-->
            <!--            <div class="topbar-right text-left">-->
            <!--                <div class="ttm-social-links-wrapper list-inline" style="padding:0px;">-->
            <!--                    <ul class="social-icons">-->
            <!--                        <li><a href="#" class="fb"><i class="fa fa-facebook"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="tw"><i class="fa fa-twitter"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="pi"><i class="fa fa-pinterest"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="ln"><i class="fa fa-linkedin"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="in"><i class="fa fa-instagram"></i></a>-->
            <!--                        </li>-->
            <!--                    </ul>-->
            <!--                </div>-->
            <!--                <ul class="top-contact float-right">-->
            <!--                    <a href="#" class="float-left mail-ixon"><i class="fa fa-envelope"></i>&nbsp; info@bambooevents.com</a>-->
            <!--                    <li class="list-inline-item"><strong><a href="tel:+91 99949 24984"><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                 <li class="list-inline-item"><a href="tel:+91 99949 24984"><strong><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                </ul>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            <!--topbar end-->
            <!-- ttm-header-wrap -->
            <div id="ttm-header-wrap">
                <!-- ttm-stickable-header-w -->
                <div id="ttm-stickable-header-w" class="ttm-stickable-header-w ttm-bgcolor-white clearfix bg-transparent">
                    <div id="site-header-menu" class="site-header-menu">
                        <div class="site-header-menu-inner ttm-stickable-header">
                              <div class="container">
                                <div class="site-header-main">
                                    <!-- site-branding -->
                                    <div class="site-branding">
                                        <a class="home-link display-prop" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo-white.png" alt="logo" width="218" height="100">
                                        </a>
                                        <a class="home-link display-prop1" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo1.webp" alt="logo" width="218" height="100">
                                        </a>
                                    </div><!-- site-branding end -->
                                    <!--site-navigation -->
                                    <div id="site-navigation" class="site-navigation">
                                        <!-- header-icins -->
                                        <div class="ttm-menu-toggle">
                                            <input type="checkbox" id="menu-toggle-form" />
                                            <label for="menu-toggle-form" class="ttm-menu-toggle-block">
                                                <span class="toggle-block toggle-blocks-1"></span>
                                                <span class="toggle-block toggle-blocks-2"></span>
                                                <span class="toggle-block toggle-blocks-3"></span>
                                            </label>
                                        </div>
                                        <nav id="menu" class="menu">
                                            <ul class="dropdown">
                                                <li class=""><a href="index.php">Home</a></li>
                                                <li class=""><a href="top-event-management-companies.php">About Us</a></li>
                                                <li class=""><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                                <li class=""><a href="top-event-management-gallery.php">Gallery</a></li>
                                                <li class=""><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                                <li class="active"><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                                <li class=""><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <!--site-navigation end-->
                                </div>
                            </div>
                        </div>
                    </div><!--ttm-header-wrap end -->
                    
                </div>
            </div><!-- ttm-header-wrap END -->
                    </header>
        <!--header end-->
  <!--header end-->
        <!--page-title-start-->
        <div class="ttm-page-title-row text-center">
            <div class="section-overlay"></div>
            <div class="title-box text-center">
                <div class="container">
                    <div class="page-title-heading">
                        <h1 class="title">CONTACT BAMBOO EVENTS </h1>
                    </div>
                    <div class="breadcrumb-wrapper">
                        <div class="container">
                            <span><a title="Homepage" href="index.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a></span>
                            <span class="ttm-bread-sep ttm-textcolor-white"> &nbsp; ⁄ &nbsp;</span>
                            <span class="ttm-textcolor-white"> Contact Us</span>
                        </div>
                    </div> 
                </div> 
            </div>
        </div>
        <!--page-title-end-->

        <!--syte-main start-->
        <div class="site-main">
            <!--contact-intro-section-start-->
            <section class="ttm-row contact-details-section clearfix">
                <div class="container">
                    <!-- row -->
                    <div class="row text-left">
                        <div class="col-lg-9 col-md-9">
                            <div class=" section-title clearfix">
                                <h4>GET IN TOUCH</h4>
                                <h2 class="title">Bamboo Events Planning and Decor</h2>
                                <div class="heading-seperator"><span></span></div>
                                <!--<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’type specimen book.</p>-->
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-border ttm-btn-color-black mt-55 pull-right mb-25" href="event-managements-services-coimbatore.php" title="">View Events</a>
                        </div>
                    </div><!--row-end-->
                    <div class="row mt-25">
                        <div class="col-md-4">
                            <div class="featured-box style2 left-icon icon-align-top">
                                <div class="featured-icon">
                                    <div class="ttm-icon ttm-icon_element-size-sm ttm-icon_element-color-skincolor ttm-icon_element-style-round">
                                        <i class="ti ti-location-pin"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5>Address</h5>
                                    </div>
                                    <div class="featured-desc">
                                       <p>No.2, Ground floor,<br>D.J.Nagar,Hopescollage,<br>Near Water Tank,<br>Coimbatore-641 004.</p>
                                    <!--<p>No.45A, Kalluri Nagar,<br>Near Peelamedu Fire Station,<br>Periyar Nagar, Masakalipalayam,<br>Peelamedu, Coimbatore-641004.<br>Tamilnadu, India.</p>-->
                                    </div>
                                </div>
                            </div><!-- featured-box end-->
                        </div>
                        <div class="col-md-4">
                            <div class="featured-box style2 left-icon icon-align-top">
                                <div class="featured-icon">
                                    <div class="ttm-icon ttm-icon_element-size-sm ttm-icon_element-color-skincolor ttm-icon_element-style-round">
                                        <i class="ti ti-email"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5>E-Mail</h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p><a href="mailto:info@bambooevents.co.in">info@bambooevents.co.in</a></p>
                                        <p><a href="mailto:enquiry@bambooevents.co.in">enquiry@bambooevents.co.in</a></p>
                                    </div>
                                </div>
                            </div><!-- featured-box end-->
                        </div>
                        <div class="col-md-4">
                            <div class="featured-box style2 left-icon icon-align-top">
                                <div class="featured-icon">
                                    <div class="ttm-icon ttm-icon_element-size-sm ttm-icon_element-color-skincolor ttm-icon_element-style-round">
                                        <i class="ti ti-headphone-alt"></i>
                                    </div>
                                </div>
                                <div class="featured-content">
                                    <div class="featured-title">
                                        <h5>Phone</h5>
                                    </div>
                                    <div class="featured-desc">
                                        <p><a href="tel:+91 9994924984">+91 99949 24984</a></p>
                                        <p><a href="tel:+91 9500355564">+91 95003 55564</a></p>
                                        
                                    </div>
                                </div>
                            </div><!-- featured-box end-->
                        </div>
                    </div>
                </div>
            </section>
            <!--contact-intro-section-end-->
            <section class="ttm-row contact-form-section2 bg-layer break-991-colum clearfix">
                <div class="container">
                   <div class="row res-1199-mlr-15">
                        <div class="col-md-4 col-lg-4">
                            <!-- col-bg-img-three -->
                            <div class="col-bg-img-three ttm-col-bgimage-yes ttm-bg">
                                <div class="ttm-col-wrapper-bg-layer ttm-bg-layer"></div>
                                <div class="layer-content"></div>
                            </div><!-- col-bg-img-three end-->
                            <!--<img src="images/bg-image/col-bgimage-3.jpg" class="ttm-equal-height-image" alt="contact bamboo event planner">-->
                        </div>
                        <div class="col-md-8 col-lg-8">
                            <div class="padding-12 box-shadow">
                                <!-- section title -->
                                <div class="section-title clearfix mb-30">
                                    <h3 class="title">Get The Party Started</h3>
                                    <p>Bamboo Events Planning and decor is one of Coimbatore's best event management companies, assists clients in making their events grandly memorable throughout their lifetime. Share your contact information, our event organizing team will get back to you shortly. </p>
                                </div><!-- section title end -->
                                <form id="contactform" class="row contactform wrap-form clearfix" method="post" action="mail.php">
                                    <label class="col-md-6">
                                        <i class="ti ti-user"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="name" type="text" value="" placeholder="Your Name:*" required="required"></span>
                                    </label>
                                    <label class="col-md-6">
                                        <i class="ti ti-email"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="email" type="text" value="" placeholder="Your email-id:*" required="required"></span>
                                    </label>
                                     <label class="col-md-6">
                                        <i class="ti ti-location-pin"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="venue" type="text" value="" placeholder="Location" required="required"></span>
                                    </label>
                                    <label class="col-md-6">
                                        <i class="ti ti-mobile"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="phone" type="text" value="" placeholder="Your Number:*" required="required"></span>
                                    </label>
                                    
                                       <label class="col-md-12">
                                        <!--<i class="ti ti-money"></i>-->
                                        <i class="fa fa-money" aria-hidden="true"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="budget" type="text" value="" placeholder="Budget" required="required"></span>
                                       </label>
                                      
                                  <!--<input type="hidden" name="recaptchaResponse" id="recaptchaResponse">-->
   
                                       
                                    <label class="col-md-12">
                                        <i class="ti ti-comment"></i>
                                        <span class="ttm-form-control"><textarea class="text-area" name="message" placeholder="Your Message:*" required="required"></textarea></span>
                                    </label>
                                    
                                    <input name="contactform" type="submit" value="Make a Reservation" class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-20" id="submit" title="Make a Reservation">
                               </form>
                            </div>
                        </div>
                    </div> 
                </div>
            </section>
            <!--map-start-->
            <!--<div class="map-wrapper">-->
            <!--    <div id="map_canvas"></div>-->
            <!--</div>-->
            <div class="container-fluid" style="padding:0px; padding-top:25px;">
                <div class="row">
                    <div class="col-md-12">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15665.076807696829!2d77.0124003!3d11.0184176!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x79043b2f544297fa!2sBamboo%20Events%20Planning%20%26%20Decor!5e0!3m2!1sen!2sin!4v1617275360913!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div><!-- /.col-md-12 -->
                </div><!-- /.row -->
            </div>
            <!--map-end-->
            <!--CTA-section-start-->
            <section class="ttm-row cta-section style2 ttm-bgcolor-skincolor clearfix">
                <div class="container">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="featured-box iconalign-before-heading">
                                <div class="featured-content">
                                    <div class="featured-icon">
                                        <div class="ttm-icon ttm-icon_element-color-white ttm-icon_element-size-sm"> 
                                            <i class="ti ti-headphone"></i>
                                        </div>
                                    </div>
                                    <div class="featured-title">
                                        <h6 class="ttm-textcolor-white">Schedule an appointment if you have any questions.</h6>
                                        <h5 class="ttm-textcolor-white">Contact our team at <a href="tel:+91 9994924984">+91 99949 24984</a> & <a href="tel:+91 9500355564">+91 95003 55564</a></h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-border ttm-btn-color-white pull-right res-mt20-767" href="bamboo-event-planner-enquiry.php">Book Now!</a>
                        </div>
                    </div>
                </div>
            </section>
            <!--CTA-section-END-->
           
        </div><!-- site-main end --> 

       <!--footer--> 
        <footer class="footer widget-footer bg-img11 ttm-bgcolor-black ttm-bg ttm-bgimage-yes clearfix">
            <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
            <div class="second-footer">
                <div class="container">
                    <div class="second-footer-inner">
                        <div class="row">
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">Quick Links </h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="top-event-management-companies.php">Why Us</a></li>
                                        <li><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                        <li><a href="top-event-management-gallery.php">Gallery</a></li>
                                        <li><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                        <li><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                        <li><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="engagement-planner-coimbatore.php">Engagement</a></li>
                                        <li><a href="wedding-planner-coimbatore-india.php">Wedding Planner</a></li>
                                        <li><a href="top-best-destination-wedding-planners.php">Destination Wedding</a></li>
                                        <li><a href="corporate-event-management-companies.php">Corporate Events</a></li>
                                        <li><a href="product-launch-event-organizers-chennai.php">Product Launch Events</a></li>
                                        <li><a href="company-award-ceremony-event-planner.php">Company Award Ceremony</a></li>
                                        <li><a href="virtual-online-event-management-organizers.php">Virtual Event Planner</a></li>
                                        <li><a href="corporate-social-event-planner-india.php">Corporate Social Events</a></li>
                                        <li><a href="exhibition-stall-design-fabricators-services.php">Exhibition Stall</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix ">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="birthday-party-event-management.php">Birthday Party</a></li>
                                        <li><a href="housewarmig-functions-organizer.php">Housewarming</a></li>
                                        <li><a href="baby-naming-ceremony-events.php">Baby Naming Ceremony</a></li>
                                        <li><a href="puberty-event-function-organizer.php">Puberty Function</a></li>
                                        <li><a href="bangle-ceremony-event-valaikappu-function.php">Bangle Ceremony</a></li>
                                        <li><a href="sangeet-mehendi-ceremony-coimbatore.php">Sangeet & Mehendi</a></li>
                                        <li><a href="wedding-anniversary-event-planner.php">Anniversary</a></li>
                                        <li><a href="school-college-alumni-event-planners.php">College/School Alumni</a></li>
                                    </ul>
                                    <!--<h4 class="widget-title">Frequent Questions</h4>
                                    <ul class="widget-text">
                                        <li><a href="#">How Can I Set An Event? </a></li>
                                        <li><a href="#">What Venues Do You Use? </a></li>
                                        <li><a href="#">Event Catalogue </a></li>
                                        <li><a href="#">Shipping & Delivery </a></li>
                                        <li><a href="#">What's your dream job? </a></li>
                                    </ul>-->
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix">
                                    <h4 class="widget-title">Contact Us</h4>
                                    <ul class="widget-contact">
                                        <!--<li><i class="fa fa-map-marker"></i>No.45A, Kalluri Nagar,<br>Near Peelamedu Fire Station,<br>Periyar Nagar,<br>Masakalipalayam,<br>Peelamedu,<br>Coimbatore-641004.</li>-->
                                        <li><i class="fa fa-map-marker"></i>No.2, Ground floor,<br>D.J.Nagar,Hopescollage,<br>Near Water Tank,<br>Coimbatore-641 004.</li>
                                        <li><i class="fa fa-envelope-o"></i><a href="mailto:enquiry@bambooevents.co.in">enquiry@bambooevents.co.in</a></li>
                                        <li><a href="tel:+919994924984"><i class="fa fa-phone"></i>+91 99949 24984</li></a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-footer-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-xs-12 ttm-footer2-left">
                            <div class="company-info" style="color: #fff;">
                                  <P>Copyright © 2023 <span style="color: #b4cd29;">Bamboo Events Planning &amp; Decor</span>. All Rights Reserved. Designed By <a href="https://www.xcodefix.com/"target="_blank">Xcodefix</a></P>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xs-12 col-md-4 ttm-footer2-right">
                            <div class="ttm-social-link-wrapper list-inline" style="padding:2px;">
                                <ul class="social-icons">
                                    <ul class="social-icons">
                                    <li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li><a href="https://www.instagram.com/bambooevents_cbe/" class="in"><i class="fa fa-instagram"></i></a>
                                    </li>
                                    <li><a href="https://twitter.com/BambooDecors" class="tw"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    <li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" class="ln"><i class="fa fa-youtube-play"></i></a>
                                    </li>
                                    
                                </ul>
                                    <!--<li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a></li>-->
                                    <!--<li><a href="https://twitter.com/BambooDecors" target="_blank"><i class="fa fa-twitter"></i></a></li>-->
                                    <!--<li><a href="https://www.instagram.com/bambooevents_cbe/" target="_blank"><i class="fa fa-instagram"></i></a></li>-->
                                    <!--<li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" target="_blank"><i class="fa fa-youtube-play"></i></a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
</div>       <div class="side-icons">
    <div class="inner-side-icon">
        <a href="https://wa.me/+919994924984?text=I'm%20interested%20in%20your%20Bamboo%20Events%20Services" target="_blank"><i class="fa fa-whatsapp" style="font-size: 48px;"></i></a> 
    </div>
    <div class="inner-side-icon">
        <a href="tel:+919994924984"><i class="fa fa-phone" style="font-size: 48px;"></i></a>
    </div>
</div>
    <!--back-to-top start-->
    <a id="totop" href="#top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!--back-to-top end-->



    <!-- Javascript -->

    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/jquery.easing.js"></script>
    <script src="js/jquery-validate.js"></script>     
    <script src="js/jquery-waypoints.js"></script>    
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="http://maps.googleapis.com/maps/api/js?key="></script>
    <script src="js/main.js"></script>
    <script src="https://www.google.com/recaptcha/api.js"></script>
   
    <!-- <script>-->

    <!--    function initialize() {-->
    <!--        var latlng = new google.maps.LatLng(-34.397, 150.644);-->
    <!--        var myOptions = {-->
    <!--            zoom: 8,-->
    <!--            center: latlng,-->
    <!--            mapTypeId: google.maps.MapTypeId.ROADMAP-->
    <!--        };-->
    <!--        var map = new google.maps.Map(document.getElementById("map_canvas"),-->
    <!--                myOptions);-->
    <!--    }-->
    <!--    google.maps.event.addDomListener(window, "load", initialize);-->

    <!--</script>-->
    
<!--      <script>-->
				 
<!--grecaptcha.ready(function () {-->
<!--grecaptcha.execute('6Lemt9wkAAAAAGTG3SbboRwpUfRVSXXKmDeIzd9M', { action: 'contact' }).then(function (token) {-->
    
<!-- document.getElementById("recaptchaResponse").value = token;-->

<!-- console.log(token);-->

<!--});-->
<!--});-->
<!--</script>-->


</body>

<!-- Mirrored from themetechmount.com/html/planwey/contact-us.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Mar 2021 05:50:12 GMT -->
</html>