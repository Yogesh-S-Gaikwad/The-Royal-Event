<!DOCTYPE html>
<html lang="en">
<head>

<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <title>Event Planner/Organizer Company in Coimbatore, Tamilnadu, India</title>
<meta name="description" content="Bamboo Events is an Event Planner Company in Coimbatore that ensures that you have an enjoyable, well-organized event and keeping it within budget." />


 <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->

<!-- favicon icon -->
<link rel="shortcut icon" href="images/favicon.png" />
<!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<!-- animate -->
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<!-- owl-carousel -->
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<!-- fontawesome -->
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<!-- themify -->
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<!-- flaticon -->
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<!-- REVOLUTION LAYERS STYLES -->
<link rel="stylesheet" type="text/css" href="revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="revolution/css/settings.css">

<!-- prettyphoto -->
<link rel="stylesheet" type="text/css"             
href="css/prettyPhoto.css">

<!-- shortcodes -->
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>

<!-- main -->
<link rel="stylesheet" type="text/css" href="css/main.css"/>

<!-- responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
</head>

<body>
    
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P6N5G4L"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    <!--page start-->
  
     <div class="page">
<header id="masthead" class="header ttm-header-style-classic">
            <!--topbar start-->
            <!--<div class="ttm-topbar-wrapper ttm-bgcolor-skincolor ttm-textcolor-white clearfix bg-white top-header">-->
            <!--    <div class="container">-->
            <!--        <div class="ttm-topbar-content">-->
            <!--            <div class="topbar-right text-left">-->
            <!--                <div class="ttm-social-links-wrapper list-inline" style="padding:0px;">-->
            <!--                    <ul class="social-icons">-->
            <!--                        <li><a href="#" class="fb"><i class="fa fa-facebook"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="tw"><i class="fa fa-twitter"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="pi"><i class="fa fa-pinterest"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="ln"><i class="fa fa-linkedin"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="in"><i class="fa fa-instagram"></i></a>-->
            <!--                        </li>-->
            <!--                    </ul>-->
            <!--                </div>-->
            <!--                <ul class="top-contact float-right">-->
            <!--                    <a href="#" class="float-left mail-ixon"><i class="fa fa-envelope"></i>&nbsp; info@bambooevents.com</a>-->
            <!--                    <li class="list-inline-item"><strong><a href="tel:+91 99949 24984"><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                 <li class="list-inline-item"><a href="tel:+91 99949 24984"><strong><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                </ul>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            <!--topbar end-->
            <!-- ttm-header-wrap -->
            <div id="ttm-header-wrap">
                <!-- ttm-stickable-header-w -->
                <div id="ttm-stickable-header-w" class="ttm-stickable-header-w ttm-bgcolor-white clearfix bg-transparent">
                    <div id="site-header-menu" class="site-header-menu">
                        <div class="site-header-menu-inner ttm-stickable-header">
                              <div class="container">
                                <div class="site-header-main">
                                    <!-- site-branding -->
                                    <div class="site-branding">
                                        <a class="home-link display-prop" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo-white.png" alt="logo" width="218" height="100">
                                        </a>
                                        <a class="home-link display-prop1" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo1.webp" alt="logo" width="218" height="100">
                                        </a>
                                    </div><!-- site-branding end -->
                                    <!--site-navigation -->
                                    <div id="site-navigation" class="site-navigation">
                                        <!-- header-icins -->
                                        <div class="ttm-menu-toggle">
                                            <input type="checkbox" id="menu-toggle-form" />
                                            <label for="menu-toggle-form" class="ttm-menu-toggle-block">
                                                <span class="toggle-block toggle-blocks-1"></span>
                                                <span class="toggle-block toggle-blocks-2"></span>
                                                <span class="toggle-block toggle-blocks-3"></span>
                                            </label>
                                        </div>
                                        <nav id="menu" class="menu">
                                            <ul class="dropdown">
                                                <li class=""><a href="index.php">Home</a></li>
                                                <li class=""><a href="top-event-management-companies.php">About Us</a></li>
                                                <li class=""><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                                <li class=""><a href="top-event-management-gallery.php">Gallery</a></li>
                                                <li class=""><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                                <li class=""><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                                <li class="active"><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <!--site-navigation end-->
                                </div>
                            </div>
                        </div>
                    </div><!--ttm-header-wrap end -->
                    
                </div>
            </div><!-- ttm-header-wrap END -->
                    </header>
        <!--header end-->
        <!--header end-->
        <!--page-title-start-->
        <div class="ttm-page-title-row text-center">
            <div class="section-overlay"></div>
            <div class="title-box text-center">
                <div class="container">
                    <div class="page-title-heading">
                        <h1 class="title">
Are You Looking For An Event Planner?
</h1>
                    </div>
                    <div class="breadcrumb-wrapper">
                        <div class="container">
                            <span><a title="Homepage" href="index.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a></span>
                            <span class="ttm-bread-sep ttm-textcolor-white"> &nbsp; ⁄ &nbsp;</span>
                            <span class="ttm-textcolor-white">Enquiry</span>
                        </div>
                    </div> 
                </div> 
            </div>
        </div>
        <!--page-title-end-->

        <!--syte-main start-->
        <div class="site-main">
            <!--contact-intro-section-start-->
            <section class="ttm-row contact-details-section clearfix">
                <div class="container">
                    <!-- row -->
                  <!--   <div class="row text-left">
                        <div class="col-lg-9 col-md-9">
                            <div class=" section-title clearfix">
                                <h4>GET IN TOUCH</h4>
                                <h2 class="title">Enquiry About Our Service</h2>
                                <div class="heading-seperator"><span></span></div>
                                <!--<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry’type specimen book.</p>-->
                        <!--      </div>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-border ttm-btn-color-black mt-55 pull-right mb-25" href="event-managements-services-coimbatore.php" title="">View Events</a>
                        </div>
                    </div> --> 
                    <!--<div class="row mt-25">-->
                    <!--    <div class="col-md-4">-->
                    <!--        <div class="featured-box style2 left-icon icon-align-top">-->
                    <!--            <div class="featured-icon">-->
                    <!--                <div class="ttm-icon ttm-icon_element-size-sm ttm-icon_element-color-skincolor ttm-icon_element-style-round">-->
                    <!--                    <i class="ti ti-location-pin"></i>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--            <div class="featured-content">-->
                    <!--                <div class="featured-title">-->
                    <!--                    <h5>Address</h5>-->
                    <!--                </div>-->
                    <!--                <div class="featured-desc">-->
                    <!--                    <p>No.45A, Kalluri Nagar,<br>Near Peelamedu Fire Station,<br>Periyar Nagar, Masakalipalayam,<br>Peelamedu, Coimbatore-641004.<br>Tamilnadu, India.</p>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--        </div><!-- featured-box end-->
                    <!--    </div>-->
                    <!--    <div class="col-md-4">-->
                    <!--        <div class="featured-box style2 left-icon icon-align-top">-->
                    <!--            <div class="featured-icon">-->
                    <!--                <div class="ttm-icon ttm-icon_element-size-sm ttm-icon_element-color-skincolor ttm-icon_element-style-round">-->
                    <!--                    <i class="ti ti-email"></i>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--            <div class="featured-content">-->
                    <!--                <div class="featured-title">-->
                    <!--                    <h5>E-Mail</h5>-->
                    <!--                </div>-->
                    <!--                <div class="featured-desc">-->
                    <!--                    <p><a href="mailto:info@bambooevents.co.in">info@bambooevents.co.in</a></p>-->
                    <!--                    <p><a href="mailto:enquiry@bambooevents.co.in">enquiry@bambooevents.co.in</a></p>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--        </div><!-- featured-box end-->
                    <!--    </div>-->
                    <!--    <div class="col-md-4">-->
                    <!--        <div class="featured-box style2 left-icon icon-align-top">-->
                    <!--            <div class="featured-icon">-->
                    <!--                <div class="ttm-icon ttm-icon_element-size-sm ttm-icon_element-color-skincolor ttm-icon_element-style-round">-->
                    <!--                    <i class="ti ti-headphone-alt"></i>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--            <div class="featured-content">-->
                    <!--                <div class="featured-title">-->
                    <!--                    <h5>Phone</h5>-->
                    <!--                </div>-->
                    <!--                <div class="featured-desc">-->
                    <!--                    <p><a href="tel:+91 9994924984">+91 99949 24984</a></p>-->
                    <!--                    <p><a href="tel:+91 9994924984">+91 99949 24984</a></p>-->
                    <!--                    <p><a href="tel:+91 9994924984">+91 99949 24984</a></p>-->
                    <!--                </div>-->
                    <!--            </div>-->
                    <!--        </div><!-- featured-box end-->
                    <!--    </div>-->
                    <!--</div>-->
                </div>
            </section>
            <!--contact-intro-section-end-->
            <section class="ttm-row contact-form-section2 bg-layer break-991-colum clearfix">
                <div class="container">
                   <div class="row res-1199-mlr-15">
                        <div class="col-md-8 col-lg-8">
                            <div class="padding-12 box-shadow">
                                <!-- section title -->
                                <div class="section-title clearfix mb-30">
                                    <h3 class="title">Hire An Expert Event Planner Company!</h3>
                                    <p>We ensure that you have an enjoyable, well-organized event free of hassle, and keeping it within budget.</p>
                                </div><!-- section title end -->
                                <form id="contactform" class="row contactform wrap-form clearfix" method="post" action="enquiry-mail.php">
                                    <label class="col-md-6">
                                        <i class="ti ti-user"></i>
                                        <span class="ttm-form-control "><input class="text-input" name="name" type="text" value="" placeholder="Your Name:*" required></span>
                                    </label>
                                    <label class="col-md-6">
                                        <i class="ti ti-email"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="email" type="text" value="" placeholder="Your email-id:*" required></span>
                                    </label>
                                     <label class="col-md-6">
                                        <i class="ti ti-location-pin"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="venue" type="text" value="" placeholder="Location" required></span>
                                    </label>
                                    <label class="col-md-6">
                                        <i class="ti ti-mobile"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="phone" type="text" value="" placeholder="Your Number:*" required></span>
                                    </label>
                                    <label class="col-md-6">
                                        <i class="ti ti-angle-down"></i>
                                        <span class="ttm-form-control">
                                            <select name="Event-plan" class="country_to_state country_select" tabindex="-1" aria-hidden="true" required>
                                                <option value="1">Select Your Event Here</option>
                                                <option value="Wedding Planne">Wedding Planner</option>
                                                <option value="Corporate Events">Corporate Events</option>
                                                <option value="Birthday Party">Birthday Party</option>
                                                <option value="Housewarming">Housewarming</option>
                                                <option value="Puberty Function">Puberty Function</option>
                                                <option value="Engagement">Engagement</option>
                                                <option value="Anniversary">Anniversary</option>
                                                <option value="Exhibition Stall">Exhibition Stall</option>
                                                <option value="College/School Alumni">College/School Alumni</option>
                                            <!--     <option value="11">Stage Events</option>
                                                <option value="12">Stage Decoration</option>
                                                <option value="13">Ear Boring</option>-->
                                                <option value="Bangle Ceremony">Bangle Ceremony</option> 
                                                <option value="Sangeet & Mehendi">Sangeet & Mehendi</option>
                                                <option value="Baby Naming Ceremony">Baby Naming Ceremony</option>
                                            </select></span>
                                    </label>
                                     <label class="col-md-6">
                                        <!--<i class="ti ti-money"></i>-->
                                        <i class="fa fa-money" aria-hidden="true"></i>
                                        <span class="ttm-form-control"><input class="text-input" name="budget" type="text" value="" placeholder="Budget:*" required></span>
                                    </label>
                                    <label class="col-md-12">
                                        <i class="ti ti-comment"></i>
                                        <span class="ttm-form-control"><textarea class="text-area" name="message" placeholder="Your Message:*" required rows="7"></textarea></span>
                                    </label>
                                    
                                    <div class="text-center col-lg-6">
                                        <input type="hidden" name="recaptchaResponse" id="recaptchaResponse">
                                        <!--<div class="g-recaptcha" data-sitekey="6Lemt9wkAAAAAGTG3SbboRwpUfRVSXXKmDeIzd9M"></div>-->
                                    </div>
                                    <label class="col-lg-6">
                                        <input name="enquiryform" type="submit" value="Enquiry Now" class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-20" id="submit" title="Make a Reservation">
                                    </label>
                                    
                               </form>
                            </div>
                        </div>
                       <div class="col-md-4 col-lg-4">
                           <div class="event-header">
                               <h4>Services of Bamboo Events</h4>
                           </div>
                            <ul class="enquiry-order">
                                <li class="enquiry-list"><a href="wedding-planner-coimbatore-india.php">Wedding Planner</a></li>
                                <li class="enquiry-list"><a href="corporate-event-management-companies.php">Corporate Events</a></li>
                                <li class="enquiry-list"><a href="birthday-party-event-management.php">Birthday Party</a></li>
                                <li class="enquiry-list"><a href="housewarmig-functions-organizer.php">Housewarming</a></li>
                                <li class="enquiry-list"><a href="puberty-event-function-organizer.php">Puberty Function</a></li>
                                <li class="enquiry-list"><a href="engagement-planner-coimbatore.php">Engagement</a></li>
                                <li class="enquiry-list"><a href="wedding-anniversary-event-planner.php">Anniversary</a></li>
                                <li class="enquiry-list"><a href="exhibition-stall-design-fabricators-services.php">Exhibition Stall</a></li>
                                <li class="enquiry-list"><a href="school-college-alumni-event-planners.php">College/School Alumni</a></li>
                               <!--  <li class="enquiry-list"><a href="#">Stage Events</a></li>
                                <li class="enquiry-list"><a href="#">Stage Decoration</a></li>
                                <li class="enquiry-list"><a href="#">Ear Boring</a></li> --> 
                                <li class="enquiry-list"><a href="bangle-ceremony-event-valaikappu-function.php">Bangle Ceremony</a></li>
                                <li class="enquiry-list"><a href="sangeet-mehendi-ceremony-coimbatore.php">Sangeet & Mehendi</a></li>
                                <li class="enquiry-list"><a href="baby-naming-ceremony-events.php">Baby Naming Ceremony</a></li>
                                
                             <!--   <li class="enquiry-list"><a href="wedding-anniversary-event-planner.php">Anniversary</a></li>
                                <li class="enquiry-list"><a href="exhibition-stall-design-fabricators-services.php">Exhibition Stall</a></li>
                                <li class="enquiry-list"><a href="school-college-alumni-event-planners.php">College/School Alumni</a></li>
                                <li class="enquiry-list"><a href="stage-event-planners-organizer.php">Stage Events</a></li>
                                <li class="enquiry-list"><a href="stage-events-decorators-coimbatore.php">Stage Decoration</a></li>
                                <li class="enquiry-list"><a href="ear-borning-kathu-kuthu-function.php">Ear Boring</a></li>
                                <li class="enquiry-list"><a href="bangle-ceremony-event-valaikappu-function.php">Bangle Ceremony</a></li>
                                <li class="enquiry-list"><a href="sangeet-mehendi-ceremony-coimbatore.php">Sangeet & Mehendi</a></li>
                                <li class="enquiry-list"><a href="baby-naming-ceremony-events.php">Baby Naming Ceremony</a></li> -->
                            </ul>
                        </div>
                    </div> 
                </div>
            </section>
        </div><!-- site-main end --> 
        
        
        <section class="ttm-row row-text-section ttm-bgcolor-grey">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="sep-box text-center">
                                <h2 class="title">We’ll Make Your Next Event Celebration Very Special!</h2>
                                <p>The Bamboo Events Planning and Decor is an exponentially evolving full-service Event Management and Party Planners in Coimbatore, which will render best-in-class services for planning, building, and implementing parties and events of all natures to prove ourselves as the foremost brand in event planning and execution. Your search for an event organizer ends at Bamboo Events Planning and Decor.</p>
                                <h6>For all of your questions, we have a supportive helpdesk!</h6>
                                <div class="sep_holder_box width-30 pt-10">
                                    <span class="sep_holder"><span class="sep_line"></span></span>
                                    <div class="ttm-icon ttm-icon_element-color-skincolor ttm-icon_element-size-md"> 
                                        <i class="fa fa-phone" style="color: #b4cd29;"></i>
                                    </div>
                                    <span class="sep_holder"><span class="sep_line"></span></span>
                                </div>
                                <h4><strong>Call Us</strong>: <a href="tel:+91 9994924984">+91 99949 24984</a> & <a href="tel:+91 9500355564">+91 95003 55564 </a></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            
       <!--footer--> 
        <footer class="footer widget-footer bg-img11 ttm-bgcolor-black ttm-bg ttm-bgimage-yes clearfix">
            <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
            <div class="second-footer">
                <div class="container">
                    <div class="second-footer-inner">
                        <div class="row">
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">Quick Links </h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="top-event-management-companies.php">Why Us</a></li>
                                        <li><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                        <li><a href="top-event-management-gallery.php">Gallery</a></li>
                                        <li><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                        <li><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                        <li><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="engagement-planner-coimbatore.php">Engagement</a></li>
                                        <li><a href="wedding-planner-coimbatore-india.php">Wedding Planner</a></li>
                                        <li><a href="top-best-destination-wedding-planners.php">Destination Wedding</a></li>
                                        <li><a href="corporate-event-management-companies.php">Corporate Events</a></li>
                                        <li><a href="product-launch-event-organizers-chennai.php">Product Launch Events</a></li>
                                        <li><a href="company-award-ceremony-event-planner.php">Company Award Ceremony</a></li>
                                        <li><a href="virtual-online-event-management-organizers.php">Virtual Event Planner</a></li>
                                        <li><a href="corporate-social-event-planner-india.php">Corporate Social Events</a></li>
                                        <li><a href="exhibition-stall-design-fabricators-services.php">Exhibition Stall</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix ">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="birthday-party-event-management.php">Birthday Party</a></li>
                                        <li><a href="housewarmig-functions-organizer.php">Housewarming</a></li>
                                        <li><a href="baby-naming-ceremony-events.php">Baby Naming Ceremony</a></li>
                                        <li><a href="puberty-event-function-organizer.php">Puberty Function</a></li>
                                        <li><a href="bangle-ceremony-event-valaikappu-function.php">Bangle Ceremony</a></li>
                                        <li><a href="sangeet-mehendi-ceremony-coimbatore.php">Sangeet & Mehendi</a></li>
                                        <li><a href="wedding-anniversary-event-planner.php">Anniversary</a></li>
                                        <li><a href="school-college-alumni-event-planners.php">College/School Alumni</a></li>
                                    </ul>
                                    <!--<h4 class="widget-title">Frequent Questions</h4>
                                    <ul class="widget-text">
                                        <li><a href="#">How Can I Set An Event? </a></li>
                                        <li><a href="#">What Venues Do You Use? </a></li>
                                        <li><a href="#">Event Catalogue </a></li>
                                        <li><a href="#">Shipping & Delivery </a></li>
                                        <li><a href="#">What's your dream job? </a></li>
                                    </ul>-->
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix">
                                    <h4 class="widget-title">Contact Us</h4>
                                    <ul class="widget-contact">
                                        <!--<li><i class="fa fa-map-marker"></i>No.45A, Kalluri Nagar,<br>Near Peelamedu Fire Station,<br>Periyar Nagar,<br>Masakalipalayam,<br>Peelamedu,<br>Coimbatore-641004.</li>-->
                                        <li><i class="fa fa-map-marker"></i>No.2, Ground floor,<br>D.J.Nagar,Hopescollage,<br>Near Water Tank,<br>Coimbatore-641 004.</li>
                                        <li><i class="fa fa-envelope-o"></i><a href="mailto:enquiry@bambooevents.co.in">enquiry@bambooevents.co.in</a></li>
                                        <li><a href="tel:+919994924984"><i class="fa fa-phone"></i>+91 99949 24984</li></a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-footer-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-xs-12 ttm-footer2-left">
                            <div class="company-info" style="color: #fff;">
                                  <P>Copyright © 2023 <span style="color: #b4cd29;">Bamboo Events Planning &amp; Decor</span>. All Rights Reserved. Designed By <a href="https://www.xcodefix.com/"target="_blank">Xcodefix</a></P>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xs-12 col-md-4 ttm-footer2-right">
                            <div class="ttm-social-link-wrapper list-inline" style="padding:2px;">
                                <ul class="social-icons">
                                    <ul class="social-icons">
                                    <li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li><a href="https://www.instagram.com/bambooevents_cbe/" class="in"><i class="fa fa-instagram"></i></a>
                                    </li>
                                    <li><a href="https://twitter.com/BambooDecors" class="tw"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    <li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" class="ln"><i class="fa fa-youtube-play"></i></a>
                                    </li>
                                    
                                </ul>
                                    <!--<li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a></li>-->
                                    <!--<li><a href="https://twitter.com/BambooDecors" target="_blank"><i class="fa fa-twitter"></i></a></li>-->
                                    <!--<li><a href="https://www.instagram.com/bambooevents_cbe/" target="_blank"><i class="fa fa-instagram"></i></a></li>-->
                                    <!--<li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" target="_blank"><i class="fa fa-youtube-play"></i></a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
</div>       <div class="side-icons">
    <div class="inner-side-icon">
        <a href="https://wa.me/+919994924984?text=I'm%20interested%20in%20your%20Bamboo%20Events%20Services" target="_blank"><i class="fa fa-whatsapp" style="font-size: 48px;"></i></a> 
    </div>
    <div class="inner-side-icon">
        <a href="tel:+919994924984"><i class="fa fa-phone" style="font-size: 48px;"></i></a>
    </div>
</div>
    <!--back-to-top start-->
    <a id="totop" href="#top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!--back-to-top end-->



    <!-- Javascript -->

    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/jquery.easing.js"></script>
    <script src="js/jquery-validate.js"></script>     
    <script src="js/jquery-waypoints.js"></script>    
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="http://maps.googleapis.com/maps/api/js?key="></script>
    <script src="js/main.js"></script>
    <!--<script src="https://www.google.com/recaptcha/api.js"></script>-->
     <script src="https://www.google.com/recaptcha/api.js?render=6Lemt9wkAAAAAGTG3SbboRwpUfRVSXXKmDeIzd9M"></script>


    <!-- <script>-->

    <!--    function initialize() {-->
    <!--        var latlng = new google.maps.LatLng(-34.397, 150.644);-->
    <!--        var myOptions = {-->
    <!--            zoom: 8,-->
    <!--            center: latlng,-->
    <!--            mapTypeId: google.maps.MapTypeId.ROADMAP-->
    <!--        };-->
    <!--        var map = new google.maps.Map(document.getElementById("map_canvas"),-->
    <!--                myOptions);-->
    <!--    }-->
    <!--    google.maps.event.addDomListener(window, "load", initialize);-->

    <!--</script>-->

    <script>
				 
grecaptcha.ready(function () {
grecaptcha.execute('6Lemt9wkAAAAAGTG3SbboRwpUfRVSXXKmDeIzd9M', { action: 'contact' }).then(function (token) {
    
 document.getElementById("recaptchaResponse").value = token;

 console.log(token);

});
});
</script>

</body>
</html>