<!DOCTYPE html>
<html lang="en">
<head>
    
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->

<script type="application/ld+json">
{
  "@context": "https://schema.org/", 
  "@type": "BreadcrumbList", 
  "itemListElement": [{
    "@type": "ListItem", 
    "position": 1, 
    "name": "Bamboo Events Home Page",
    "item": "https://www.bambooevents.co.in/top-event-management-companies.php"  
  },{
    "@type": "ListItem", 
    "position": 2, 
    "name": "ABOUT BAMBOO EVENTS",
    "item": "https://www.bambooevents.co.in/top-event-management-companies.php"  
  }]
}
</script>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <title>Top Event Management Companies in Coimbatore - Bamboo Event</title>
<meta name="description" content="Bamboo Events Planner and Decor is one the top and the best event management companies in Coimbatore, Organizer for all your wedding event needs" />




<style>
            .addReadMore.showlesscontent .SecSec,
    .addReadMore.showlesscontent .readLess {
        display: none;
    }

    .addReadMore.showmorecontent .readMore {
        display: none;
    }

    .addReadMore .readMore,
    .addReadMore .readLess {
        font-weight: bold;
        margin-left: 2px;
        color: #b3cc27;
        cursor: pointer;
    }

    .addReadMoreWrapTxt.showmorecontent .SecSec,
    .addReadMoreWrapTxt.showmorecontent .readLess {
        display: block;
    }
</style>

 <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->

<!-- favicon icon -->
<link rel="shortcut icon" href="images/favicon.png" />
<!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<!-- animate -->
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<!-- owl-carousel -->
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<!-- fontawesome -->
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<!-- themify -->
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<!-- flaticon -->
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<!-- REVOLUTION LAYERS STYLES -->
<link rel="stylesheet" type="text/css" href="revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="revolution/css/settings.css">

<!-- prettyphoto -->
<link rel="stylesheet" type="text/css"             
href="css/prettyPhoto.css">

<!-- shortcodes -->
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>

<!-- main -->
<link rel="stylesheet" type="text/css" href="css/main.css"/>

<!-- responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
</head>

<body>
    
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P6N5G4L"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    <!--page start-->

     <div class="page">
<header id="masthead" class="header ttm-header-style-classic">
            <!--topbar start-->
            <!--<div class="ttm-topbar-wrapper ttm-bgcolor-skincolor ttm-textcolor-white clearfix bg-white top-header">-->
            <!--    <div class="container">-->
            <!--        <div class="ttm-topbar-content">-->
            <!--            <div class="topbar-right text-left">-->
            <!--                <div class="ttm-social-links-wrapper list-inline" style="padding:0px;">-->
            <!--                    <ul class="social-icons">-->
            <!--                        <li><a href="#" class="fb"><i class="fa fa-facebook"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="tw"><i class="fa fa-twitter"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="pi"><i class="fa fa-pinterest"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="ln"><i class="fa fa-linkedin"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="in"><i class="fa fa-instagram"></i></a>-->
            <!--                        </li>-->
            <!--                    </ul>-->
            <!--                </div>-->
            <!--                <ul class="top-contact float-right">-->
            <!--                    <a href="#" class="float-left mail-ixon"><i class="fa fa-envelope"></i>&nbsp; info@bambooevents.com</a>-->
            <!--                    <li class="list-inline-item"><strong><a href="tel:+91 99949 24984"><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                 <li class="list-inline-item"><a href="tel:+91 99949 24984"><strong><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                </ul>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            <!--topbar end-->
            <!-- ttm-header-wrap -->
            <div id="ttm-header-wrap">
                <!-- ttm-stickable-header-w -->
                <div id="ttm-stickable-header-w" class="ttm-stickable-header-w ttm-bgcolor-white clearfix bg-transparent">
                    <div id="site-header-menu" class="site-header-menu">
                        <div class="site-header-menu-inner ttm-stickable-header">
                              <div class="container">
                                <div class="site-header-main">
                                    <!-- site-branding -->
                                    <div class="site-branding">
                                        <a class="home-link display-prop" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo-white.png" alt="logo" width="218" height="100">
                                        </a>
                                        <a class="home-link display-prop1" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo1.webp" alt="logo" width="218" height="100">
                                        </a>
                                    </div><!-- site-branding end -->
                                    <!--site-navigation -->
                                    <div id="site-navigation" class="site-navigation">
                                        <!-- header-icins -->
                                        <div class="ttm-menu-toggle">
                                            <input type="checkbox" id="menu-toggle-form" />
                                            <label for="menu-toggle-form" class="ttm-menu-toggle-block">
                                                <span class="toggle-block toggle-blocks-1"></span>
                                                <span class="toggle-block toggle-blocks-2"></span>
                                                <span class="toggle-block toggle-blocks-3"></span>
                                            </label>
                                        </div>
                                        <nav id="menu" class="menu">
                                            <ul class="dropdown">
                                                <li class=""><a href="index.php">Home</a></li>
                                                <li class="active"><a href="top-event-management-companies.php">About Us</a></li>
                                                <li class=""><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                                <li class=""><a href="top-event-management-gallery.php">Gallery</a></li>
                                                <li class=""><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                                <li class=""><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                                <li class=""><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <!--site-navigation end-->
                                </div>
                            </div>
                        </div>
                    </div><!--ttm-header-wrap end -->
                    
                </div>
            </div><!-- ttm-header-wrap END -->
                    </header>
        <!--header end-->        <!--header end-->

        <div class="ttm-page-title-row text-center">
            <div class="title-box text-center">
                <div class="container">
                    <div class="page-title-heading">
                        <h1 class="title">About Bamboo Events Planning and Decor</h1>
                        <p class="ttm-textcolor-white"></p>
                    </div>
                    <div class="breadcrumb-wrapper">
                        <div class="container">
                            <span><a title="Homepage" href="index.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a></span>
                            <span class="ttm-bread-sep ttm-textcolor-white"> &nbsp; ⁄ &nbsp;</span>
                            <span class="ttm-textcolor-white">About Bamboo Events </span>
                        </div>
                    </div>
                </div> 
            </div>
        </div>

        <!--header end-->
        <div class="site-main">
            <!-- about-intro-section -->
            <section class="ttm-row ttm-bgcolor-white about-intro-section clearfix">
                <div class="container">
                    <div class="row text-center">
                        <div class="col-lg-12">
                            <div class=" section-title clearfix">
                                <h4>BAMBOO EVENTS</h4>
                                <h2 class="title">Top Event Management Companies in Coimbatore</h2>
                                <div class="title-img"><img src="images/ds-1.webp" alt="Event Planners and Decorators In Coimbatore" width="87" height="23"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="ttm-tabs element-tab-style-horizontal width-shape-line clearfix">
                                <!-- tabs -->
                                <ul class="tabs connect-tabs clearfix mb-20">
                                    <li class="tab active"><a href="#">Who we are</a></li>
                                    <li class="tab"><a href="#">Our Mission!</a></li>
                                    <li class="tab"><a href="#">Our Vision!</a></li>
                                    <li class="tab"><a href="#">Promises a Feast of Event </a></li>
                                </ul>
                                <div class="content-tab">
                                    <div class="content-inner">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-6">
                                                <div class="mb-30">
                                                    <img class="img-fluid" src="images/about1.webp" alt="All Event Planners and Organizers in Coimbatore">
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                
                                               
                                                <p style="text-align:justify"> Bamboo Events Planning and Decor is one of the top event management companies, focuses on event management in Coimbatore in a way that creates a win-win situation for all involved stakeholders. Our goal is to ensure that the clients, as well as participants of the event, have an overall positive experience. To do this, we don’t look at building one-time associations with clients; instead, we aim at creating long-lasting collaborations that will span years to come. Our core purpose is to flourish the WOW customer experience and to bring prosperity to the entire ecosystem connected with her.</p>
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12">
                                                        <ul class="ttm-list ttm-list-style-icon ttm-list-color-black">
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Excellent décor designs can add a touch of style to every occasion</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Get customised destination wedding facilities and services.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Outstanding performances by talented artists will add significance to your wedding.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Celebrate your special day at one of the best and most popular venues.</span>
                                                            </li>
                                                        </ul>
                                                        <!-- <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-30 mb-20" href="#" title="">Read More</a> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="content-inner">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-6">
                                                <p style="text-align:justify">The Bamboo Events Planning and Decor is an exponentially evolving full-service Event Management and Party Planners in Coimbatore, which will render best-in-class services for planning, building, and implementing parties and events of all natures to prove ourselves as the foremost brand in event planning and execution. Among the many event management companies in Coimbatore, it isn't easy to stand out. But with Bamboo Events Planning and Decor, the best Event Planner in Coimbatore, you can be assured of promises being met and on-time delivery of all services. BAMBOO EVENTS is excited to provide ‘Uniquely Elegant and Impressive Customizations' for the whole of your events.</p>
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12">
                                                        <div class="our-services">
                                                            <ul class="ttm-list ttm-list-style-icon ttm-list-color-black">
                                                                <li>
                                                                    <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                    <span class="ttm-list-li-content">Top Event Management Company offers Packages for all your need.</span>
                                                                </li>
                                                                <li>
                                                                    <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                    <span class="ttm-list-li-content"> Help client to make the program most memorable to guest.</span>
                                                                </li>
                                                                <li>
                                                                    <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                    <span class="ttm-list-li-content">Recognized as one of the best Wedding events planners</span>
                                                                </li>
                                                                <li>
                                                                    <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                    <span class="ttm-list-li-content">More than 12 years of event planning experience</span>
                                                                </li>
                                                                <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">we are always ready to add sparkle to the special day.</span>
                                                            </li>
                                                            </ul>
                                                            <!-- <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-30 mb-20" href="#" title="">Read More</a> -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="mb-30">
                                                    <img class="img-fluid" src="images/about2.webp" alt="Party Planners in Coimbatore">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="content-inner">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-6">
                                                <div class="image-box mb-30">
                                                    <img class="img-fluid" src="images/about3.webp" alt="Best Event Planning Services">
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <p style="text-align:justify">We understand that a perfectly accomplished event can be leveraged to support a client's strategic vision, incorporated into a marketing plan, or used to build networks and client loyalty. Bamboo Events Planning and Decor approach every design with careful attention to detail and precision. Despite size and scope, we approach your event as a profession with distinct strategic aims, fixed milestones, and an overall plan to ensure that your event is delivered on time and budget. </p>
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12">
                                                        <ul class="ttm-list ttm-list-style-icon ttm-list-color-black">
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">With Passion topped up with years of decades of expertise, you will want us by your side to plan and execute your event to excellence.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">With our unique services, we are capable of organising every kind of celebration</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">An event whether big or small needs the monitoring and management of qualified and skilled professionals.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">We follow incredible work ethic to meet our clients expectation. </span>
                                                            </li>
                                                        </ul>
                                                    <!--    <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-30 mb-20" href="#" title="">Read More</a> -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="content-inner">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-6">
                                                <p style="text-align:justify">When it comes to planning your party, for Bamboo Events Planning and Decor, it always starts with diverse yet like-minded businesses with the primary objective of ‘Delivering Unrivalled Service’ and ‘Exceeding Expectations’ is our satisfaction. Bamboo Events Planning and Decor like to do things differently as we push the boundaries in event planning and deliver creativity to match each client's brand values and integrity. One thing is for sure; our passion for service and party planning sits at the heart of everything you do! </p>
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12">
                                                        <ul class="ttm-list ttm-list-style-icon ttm-list-color-black">
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Your search for an event organizer ends at Bamboo Events Planner and Decors</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">We have the skills and strength to cater and attend to every detail, whether it's a private dining event for 50 guests or a special party with a thousand guests.</span>
                                                            </li>
                                                            
                                                           <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">we assist by offering design and services that are unparalleled by any other.</span>
                                                            </li> 
                                                        </ul>
                                                      <!--  <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-30 mb-20" href="#" title="">Read More</a> -->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="mb-30">
                                                    <img class="img-fluid" src="images/about4.webp" alt="Management Companies in Coimbatore">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- about-intro-section END -->
            <!-- fid-section -->
            <section class="ttm-row fid-section count-bg clearfix">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-lg-3 counter-wrap">
                            <!--ttm-fid-content-->
                            <div class="ttm-fid text-center">
                                <div class="ttm-fid-icon-wrapper ttm-icon ttm-icon_element-color-white ttm-icon_element-size-md">
                                    <i class="fa fa-calendar-check-o "></i>
                                </div>
                                <div class="ttm-fid-contents">
                                    <h4><span   data-appear-animation = "animateDigits"
                                                data-from             = "0"
                                                data-to               = "12"
                                                data-interval         = "10"
                                                data-before           = ""
                                                data-before-style     = "sup"
                                                data-after            = ""
                                                data-after-style      = "sub"
                                            >878
                                        </span>
                                    </h4>
                                    <h3 class="ttm-fid-title"><span>EXPERIENCE<br></span></h3>
                                </div><!-- ttm-fld-contents end -->
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3 counter-wrap">
                            <div class="ttm-fid text-center">
                                <div class="ttm-fid-icon-wrapper ttm-icon ttm-icon_element-color-white ttm-icon_element-size-md">
                                    <i class="flaticon flaticon-wedding"></i>
                                </div>
                                <div class="ttm-fid-contents">
                                    <h4><span   data-appear-animation = "animateDigits"
                                                data-from             = "0"
                                                data-to               = "240"
                                                data-interval         = "5"
                                                data-before           = ""
                                                data-before-style     = "sup"
                                                data-after            = ""
                                                data-after-style      = "sub"
                                            >175
                                        </span>
                                    </h4>
                                    <h3 class="ttm-fid-title"><span>WEDDING EVENT<br></span></h3>
                                </div><!-- ttm-fld-contents end -->
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3 counter-wrap">
                            <!--ttm-fid-content-->
                            <div class="ttm-fid text-center">
                                <div class="ttm-fid-icon-wrapper ttm-icon ttm-icon_element-color-white ttm-icon_element-size-md">
                                    <i class="flaticon flaticon-cheers"></i>
                                </div>
                                <div class="ttm-fid-contents">
                                    <h4><span   data-appear-animation = "animateDigits"
                                                data-from             = "0"
                                                data-to               = "187"
                                                data-interval         = "10"
                                                data-before           = ""
                                                data-before-style     = "sup"
                                                data-after            = ""
                                                data-after-style      = "sub"
                                            >878
                                        </span>
                                    </h4>
                                    <h3 class="ttm-fid-title"><span>CORPORATE EVENT<br></span></h3>
                                </div><!-- ttm-fld-contents end-->
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3 counter-wrap">
                            <!--ttm-fid-content-->
                            <div class="ttm-fid text-center">
                                <div class="ttm-fid-icon-wrapper ttm-icon ttm-icon_element-color-white ttm-icon_element-size-md">
                                    <i class="ti ti-face-smile"></i>
                                </div>
                                <div class="ttm-fid-contents">
                                    <h4><span   data-appear-animation = "animateDigits"
                                                data-from             = "0"
                                                data-to               = "1255"
                                                data-interval         = "10"
                                                data-before           = ""
                                                data-before-style     = "sup"
                                                data-after            = ""
                                                data-after-style      = "sub"
                                            >125
                                        </span>
                                    </h4>
                                    <h3 class="ttm-fid-title"><span>HAPPY CLIENTS<br></span></h3>
                                </div><!-- ttm-fld-contents end-->
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- fid-section end -->
            <!-- feature area start -->
    <div class="feature-area ptb--100 bg-light">
        <div class="container">
            <div class="row">
                  <div class="col-lg-12 text-center">
                            <div class=" section-title clearfix">
                                <h4>CUSTOMISED EVENT DECOR SERVICES</h4>
                                <h2 class="title">How to Plan Your Wedding with Bamboo Events?</h2>
                                <div class="title-img">
                                    <img src="images/ds-1.webp" alt="Anniversary Event Organizer in Tiruppur" width="87" height="23">
                                </div>
                            </div>
                        </div>
                <div class="service-type">
              <div class="service-catagari">
                     <ul>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-restaurant"></i>
                                <span class="text">Caterers</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-ballons"></i>
                                <span class="text">Decor & Florists</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-calendar"></i>
                                <span class="text">Event Planner</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-makeup"></i>
                                <span class="text">Make-up and Hair</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-wedding-anniversary-january-calendar-page"></i>
                                <span class="text">Wedding Cards</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-mehndi"></i>
                                <span class="text">Mehandi</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-wedding-cake"></i>
                                <span class="text">Cakes</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-dj-1"></i>
                                <span class="text">DJ</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-camera"></i>
                                <span class="text">Photographers</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-stage"></i>
                                <span class="text">Entertainment</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-gift"></i>
                                <span class="text">Goody Bags / Gifts</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-exhibition-1"></i>
                                <span class="text">Accommodation</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-disco"></i>
                                <span class="text">Audio & Lighting</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-confetti"></i>
                                <span class="text">Magic Show</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-wedding-car"></i>
                                <span class="text">Vehicle Arrangement</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-pooja"></i>
                                <span class="text">Pooja Pandit</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-dj"></i>
                                <span class="text">Orchestra</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-female-flamenco-dancer"></i>
                                <span class="text">Dance</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-drum-1"></i>
                                <span class="text">Mela Vaathiyam</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="flaticon flaticon-dance-1"></i>
                                <span class="text">Wedding Music Artists</span>
                            </a>
                        </li>
                    </ul>
            
                </div>
            </div>
            </div>
        </div>
    </div>
    <!-- feature area end -->
            <!-- team-section -->
            <section class="wide-tb-120">
            <div class="container">
                <div class="col-lg-12 text-center">
                            <div class=" section-title clearfix">
                                <h4>SEE OUR BEST</h4>
                                <h2 class="title">Services of Bamboo Events </h2>
                                <div class="title-img">
                                    <img src="images/ds-1.webp" alt="Corporate Event Planners in Coimbatore" width="87" height="23">
                                </div>
                            </div>
                        </div>
                <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="zoom-img">
                        <a href="wedding-planner-coimbatore-india.php"><img class="img-fluid" src="images/wedding-planner.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="wedding-planner-coimbatore-india.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Wedding Planner"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                    <div class="event-name">
                        <a href="wedding-planner-coimbatore-india.php"><h4 class="text-white" style="margin-bottom:5px;">Wedding Planner</h4></a>
                    </div>
                        <div class="icon-links">
                <a href="wedding-planner-coimbatore-india.php"><i class="flaticon flaticon-wedding"></i></a>
                </div>   
                </div>                 
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="zoom-img">
                        <a href="corporate-event-management-companies.php"><img class="img-fluid" src="images/corporate-events.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="corporate-event-management-companies.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Corporate Events"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                    <div class="event-name">
                        <a href="corporate-event-management-companies.php"><h4 class="text-white" style="margin-bottom:5px;">Corporate Events</h4></a>
                        </div> 
                        <div class="icon-links">
                <a href="corporate-event-management-companies.php"><i class="flaticon flaticon-cheers"></i></a>
                </div>                  
                </div>                 
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="zoom-img">
                        <a href="birthday-party-event-management.php"><img class="img-fluid" src="images/birthday party.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="birthday-party-event-management.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Birthday Party"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                    <div class="event-name">
                        <a href="birthday-party-event-management.php"><h4 class="text-white" style="margin-bottom:5px;">Birthday Party</h4></a>
                        </div>
                        <div class="icon-links">
                <a href="birthday-party-event-management.php"><i class="flaticon flaticon-cake"></i></a>
                </div>                 
                </div>                 
                </div>                                 
                </div> 
                <div class="row">
                        <div class="col-md-12 text-center">
                            <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-black mt-50" href="event-managements-services-coimbatore.php">All Service</a>
                        </div>
                    </div>                
            </div>
        </section>
             <!-- testimonial-area -->
            <section class="testimonial-area testimonial-bg pt-110 pb-120">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-12 text-center">
                            <div class=" section-title clearfix">
                                <h4>SEE OUR BEST</h4>
                                <h2 class="title">What People Says About Bamboo Events</h2>
                                <div class="title-img">
                                    <img src="images/ds-1.webp" alt="Wedding Event Organizer in Coimbatore" width="87" height="23">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row testimonial-active owl-carousel testimonial-slide">
                            <div class="testimonial-item">
                                <div class="testimonial-quote">
                                    <svg version="1.1" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve">
                                        <g>
                                            <polygon points="0,4 0,28 12,16 12,4" />
                                            <polygon points="20,4 20,28 32,16 32,4" />
                                        </g>
                                    </svg>
                                </div>
                                <div class="testimonial-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="testi-content">
                                    <p class="addReadMore showlesscontent">The best decision we made for our wedding was deciding to work with  bamboo events, they made my big day memorable. our wedding planner Vidhya did an amazing job. She is so organized and professional. If you are looking for a perfect wedding planning company I highly recommend Bamboo events planning and Decor.</p>
                                    <div class="testi-avatar-wrap">
                                        <div class="testi-avatar-img">
                                            <img src="img/images/testi_avatar01.png" alt="">
                                        </div>
                                        <div class="testi-avatar-info">
                                            <h6>Rakesh Rangaraj</h6>
                                            <span>Positive: Quality & Responsiveness</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-item">
                                <div class="testimonial-quote">
                                    <svg version="1.1" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve">
                                        <g>
                                            <polygon points="0,4 0,28 12,16 12,4" />
                                            <polygon points="20,4 20,28 32,16 32,4" />
                                        </g>
                                    </svg>
                                </div>
                                <div class="testimonial-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="testi-content">
                                    <p class="addReadMore showlesscontent">Dedication, professionalism, and creativity are the core qualities of Bamboo events.. she understands the clients requirements and mindset very well works hard to deliver it in time and with best output. Will refer her again and again</p>
                                    <div class="testi-avatar-wrap">
                                        <div class="testi-avatar-img">
                                            <img src="img/images/testi_avatar02.png" alt="">
                                        </div>
                                        <div class="testi-avatar-info">
                                            <h6>Srividya Venkataraman</h6>
                                            <span>Positive: Professionalism</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-item">
                                <div class="testimonial-quote">
                                    <svg version="1.1" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve">
                                        <g>
                                            <polygon points="0,4 0,28 12,16 12,4" />
                                            <polygon points="20,4 20,28 32,16 32,4" />
                                        </g>
                                    </svg>
                                </div>
                                <div class="testimonial-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="testi-content">
                                    <p class="addReadMore showlesscontent">Without any hesitation, I will recommend Bamboo Events for any occasion in your family.We decided to have our Daughter's Half Saree Ceremony, in less than 24hours. As we were busy with managing too many things, we forgot to think about the backdrop for my daughter's occasion. At 1PM, we released this and I called up Ms. SreeVidya of Bamboo events asking her to help us. Without hesitation, she accepted this challenge and she scrambled all the workers immediately. At 6PM, the backdrop was ready at our venue. Bamboo events handled the work so professionally that everyone who attended the ceremony was awestruck by the backdrop.  I personally had to thank Ms.SreeVidya for making my daughter's ceremony memorable and grandeur. This kind of work can only be done by a person, if one can get into the shoes of others. In our case she made my daughters ceremony very very memorable. Thank you is a very simple word for Ms.SreeVidya and Bamboo events.

பயன்தூக்கார் செய்த உதவி நயன்தூக்கின்
நன்மை கடலின் பெரிது. (அறத்துப்பால்)

Keep it up and way to go!!</p>
                                    <div class="testi-avatar-wrap">
                                        <div class="testi-avatar-img">
                                            <img src="img/images/testi_avatar03.png" alt="">
                                        </div>
                                        <div class="testi-avatar-info">
                                            <h6>Saravanakumar Ponnuswamy</h6>
                                            <span>Positive: Professionalism</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-item">
                                <div class="testimonial-quote">
                                    <svg version="1.1" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve">
                                        <g>
                                            <polygon points="0,4 0,28 12,16 12,4" />
                                            <polygon points="20,4 20,28 32,16 32,4" />
                                        </g>
                                    </svg>
                                </div>
                                <div class="testimonial-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="testi-content">
                                    <p class="addReadMore showlesscontent">Bamboo events planning.. dey are gud in service...I have booked some other event planner..at last moment dey had a issues and canceled..I got a reference about bamboo events..I called them they helped me with in a day they finished all my requirements ..special thanks to...sree vidya ethiraj  she is so reasonable and friendly too..I was fully satisfied with services ...quality vice and price vice..so I highly recommend babmboo events 😃😃😃</p>
                                    <div class="testi-avatar-wrap">
                                        <div class="testi-avatar-img">
                                            <img src="img/images/testi_avatar02.png" alt="">
                                        </div>
                                        <div class="testi-avatar-info">
                                            <h6>Deepu Mithun</h6>
                                            <span>Positive: Professionalism</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="row">
                        <!--<div class="col-md-12 text-center">-->
                        <!--    <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-black mt-50" href="#">View More Review</a>-->
                        <!--</div>-->
                    </div>
                </div>
            </section>
            <!-- testimonial-area-end -->
        </div><!-- site-main end --> 
       <footer class="footer widget-footer bg-img11 ttm-bgcolor-black ttm-bg ttm-bgimage-yes clearfix">
            <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
            <div class="second-footer">
                <div class="container">
                    <div class="second-footer-inner">
                        <div class="row">
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">Quick Links </h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="top-event-management-companies.php">Why Us</a></li>
                                        <li><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                        <li><a href="top-event-management-gallery.php">Gallery</a></li>
                                        <li><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                        <li><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                        <li><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="engagement-planner-coimbatore.php">Engagement</a></li>
                                        <li><a href="wedding-planner-coimbatore-india.php">Wedding Planner</a></li>
                                        <li><a href="top-best-destination-wedding-planners.php">Destination Wedding</a></li>
                                        <li><a href="corporate-event-management-companies.php">Corporate Events</a></li>
                                        <li><a href="product-launch-event-organizers-chennai.php">Product Launch Events</a></li>
                                        <li><a href="company-award-ceremony-event-planner.php">Company Award Ceremony</a></li>
                                        <li><a href="virtual-online-event-management-organizers.php">Virtual Event Planner</a></li>
                                        <li><a href="corporate-social-event-planner-india.php">Corporate Social Events</a></li>
                                        <li><a href="exhibition-stall-design-fabricators-services.php">Exhibition Stall</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix ">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="birthday-party-event-management.php">Birthday Party</a></li>
                                        <li><a href="housewarmig-functions-organizer.php">Housewarming</a></li>
                                        <li><a href="baby-naming-ceremony-events.php">Baby Naming Ceremony</a></li>
                                        <li><a href="puberty-event-function-organizer.php">Puberty Function</a></li>
                                        <li><a href="bangle-ceremony-event-valaikappu-function.php">Bangle Ceremony</a></li>
                                        <li><a href="sangeet-mehendi-ceremony-coimbatore.php">Sangeet & Mehendi</a></li>
                                        <li><a href="wedding-anniversary-event-planner.php">Anniversary</a></li>
                                        <li><a href="school-college-alumni-event-planners.php">College/School Alumni</a></li>
                                    </ul>
                                    <!--<h4 class="widget-title">Frequent Questions</h4>
                                    <ul class="widget-text">
                                        <li><a href="#">How Can I Set An Event? </a></li>
                                        <li><a href="#">What Venues Do You Use? </a></li>
                                        <li><a href="#">Event Catalogue </a></li>
                                        <li><a href="#">Shipping & Delivery </a></li>
                                        <li><a href="#">What's your dream job? </a></li>
                                    </ul>-->
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix">
                                    <h4 class="widget-title">Contact Us</h4>
                                    <ul class="widget-contact">
                                        <!--<li><i class="fa fa-map-marker"></i>No.45A, Kalluri Nagar,<br>Near Peelamedu Fire Station,<br>Periyar Nagar,<br>Masakalipalayam,<br>Peelamedu,<br>Coimbatore-641004.</li>-->
                                        <li><i class="fa fa-map-marker"></i>No.2, Ground floor,<br>D.J.Nagar,Hopescollage,<br>Near Water Tank,<br>Coimbatore-641 004.</li>
                                        <li><i class="fa fa-envelope-o"></i><a href="mailto:enquiry@bambooevents.co.in">enquiry@bambooevents.co.in</a></li>
                                        <li><a href="tel:+919994924984"><i class="fa fa-phone"></i>+91 99949 24984</li></a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-footer-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-xs-12 ttm-footer2-left">
                            <div class="company-info" style="color: #fff;">
                                  <P>Copyright © 2023 <span style="color: #b4cd29;">Bamboo Events Planning &amp; Decor</span>. All Rights Reserved. Designed By <a href="https://www.xcodefix.com/"target="_blank">Xcodefix</a></P>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xs-12 col-md-4 ttm-footer2-right">
                            <div class="ttm-social-link-wrapper list-inline" style="padding:2px;">
                                <ul class="social-icons">
                                    <ul class="social-icons">
                                    <li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li><a href="https://www.instagram.com/bambooevents_cbe/" class="in"><i class="fa fa-instagram"></i></a>
                                    </li>
                                    <li><a href="https://twitter.com/BambooDecors" class="tw"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    <li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" class="ln"><i class="fa fa-youtube-play"></i></a>
                                    </li>
                                    
                                </ul>
                                    <!--<li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a></li>-->
                                    <!--<li><a href="https://twitter.com/BambooDecors" target="_blank"><i class="fa fa-twitter"></i></a></li>-->
                                    <!--<li><a href="https://www.instagram.com/bambooevents_cbe/" target="_blank"><i class="fa fa-instagram"></i></a></li>-->
                                    <!--<li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" target="_blank"><i class="fa fa-youtube-play"></i></a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
</div>      <div class="side-icons">
    <div class="inner-side-icon">
        <a href="https://wa.me/+919994924984?text=I'm%20interested%20in%20your%20Bamboo%20Events%20Services" target="_blank"><i class="fa fa-whatsapp" style="font-size: 48px;"></i></a> 
    </div>
    <div class="inner-side-icon">
        <a href="tel:+919994924984"><i class="fa fa-phone" style="font-size: 48px;"></i></a>
    </div>
</div>    <!--back-to-top start-->
    <a id="totop" href="#top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!--back-to-top end-->
    <!-- Javascript -->
    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/jquery.easing.js"></script>    
    <script src="js/jquery-waypoints.js"></script>    
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/numinate.min6959.js?ver=4.9.3"></script>
    <script src="js/main.js"></script>
</body>
<!-- Mirrored from themetechmount.com/html/planwey/about-us.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Mar 2021 05:46:30 GMT -->
</html>