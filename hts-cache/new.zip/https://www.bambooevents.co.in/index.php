<!DOCTYPE html>
<html lang="en">
<head>
    
     


    <meta name="google-site-verification" content="B5hqJ-bgoaMKCPqDuPS3aIofOima0hTcW3HwvYdF3RA" />
    <meta name="google-site-verification" content="ZMFyfQuAzYWLpevebrSQQiuLAkOT1xuBVQBMFWbP-Qk" />
    

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <title>Bamboo Events Planning and Decor, Coimbatore, Tamilnadu</title>
    
<meta name="description" content="The Bamboo Events Planning and Decor is an exponentially evolving full-service Event Managements and Events Party Planners in Coimbatore, Tirupur." />
<style>
    @import url('https://fonts.googleapis.com/css?family=Belleza&amp;subset=latin-ext&display=swap');@font-face{font-family:cursiveRegular;font-display:swap;src:url(../fonts/design.graffiti.comicsansmsgras.ttf)}ul,li{padding:0;margin:0;list-style:none}p{margin:0 0 15px}a:hover{color:#b4cd29;text-decoration:none}a,input{outline:medium none;color:#b4cd29}input:-moz-placeholder,input::-moz-placeholder,input:-ms-input-placeholder,input::-ms-input-placeholder,input::-webkit-input-placeholde{color:#fff}a:hover{color:#b4cd29}ul{margin:16px 0;padding:0 0 0 25px}body{font-family:cursiveRegular;font-weight:600;font-size:15px;line-height:26px;color:#828c96;background-color:#f9f9f9;letter-spacing:0.3px}h1,h4,h6{font-family:"Belleza",Arial,Helvetica,sans-serif;margin-bottom:15px;font-weight:400;color:#232323}h1{font-size:42px;line-height:52px}h4{font-size:24px;margin-bottom:20px}h6{font-size:16px;line-height:18px;font-weight:normal}body .page{overflow:hidden;position:relative;z-index:10}body .site-main{background-color:#fff;position:relative;z-index:9}#site-header-menu #site-navigation .menu ul.dropdown>li.active>a,#site-navigation .menu>ul,.ttm-header-style-classic #site-header-menu #site-navigation .menu>ul>li.active>a{color:#b4cd29}#totop,#site-header-menu #site-navigation .menu>ul>li>a:before,#site-navigation .menu ul.dropdown>li>a:before{background-color:#b4cd29}#site-header-menu #site-navigation .menu>ul>li>a{color:#323130}.ttm-bgcolor-white{background-color:#fff}.ttm-header-style-classic #site-header-menu #site-navigation .menu>ul>li>a{color:#232323}.site-branding{float:left;display:block;z-index:1;position:relative}.site-branding img{max-height:100px}.ttm-menu-toggle{float:right}.ttm-menu-toggle input[type=checkbox]{display:none}.ttm-stickable-header-w{width:100%;box-shadow:none;-webkit-box-shadow:none;-moz-box-shadow:none;-ms-box-shadow:none;-o-box-shadow:none;line-height:105px}.ttm-header-style-classic .ttm-stickable-header-w{height:105px}#totop{font-weight:900;color:#fff;display:none;position:fixed;right:34px;bottom:34px;z-index:999;height:0;width:0;font-size:0;text-align:center;padding-top:3px;line-height:37px;border-radius:3px}.wide-tb-120{padding-top:120px;padding-bottom:120px}.testimonial-item{background:#fff;position:relative;z-index:1;padding:70px 40px 50px;transform:translateY(0px)}.testimonial-item::before{content:"";position:absolute;left:13px;top:13px;right:13px;bottom:13px;border:1px solid #ebebeb;z-index:-1}.testimonial-quote svg{width:24px;height:24px}.testimonial-rating{display:flex;justify-content:flex-end;align-items:center;font-size:12px;margin-bottom:20px;color:#efc94c}.testi-content p{font-size:16px;font-style:italic;letter-spacing:.4px;margin-bottom:30px;font-weight:400}.testi-avatar-wrap{display:flex;align-items:center;flex-wrap:wrap}.testi-avatar-img{margin-right:15px}.testi-avatar-img img{border-radius:50%}.testi-avatar-info{flex-grow:1}.testi-avatar-info h6{font-size:18px;line-height:1;margin-bottom:10px}.testi-avatar-info span{display:block;font-size:13px;font-weight:500}.testimonial-quote{position:absolute;left:30px;top:30px;z-index:1}.testimonial-quote::before{content:"";position:absolute;left:-17px;top:-17px;width:0;height:0;border-style:solid;border-width:85px 85px 0 0;border-color:#b3cc27 transparent transparent transparent;z-index:-1}.testimonial-quote svg polygon{fill:#343434}.side-icons{position:fixed;z-index:9999;right:0;top:35%;box-shadow:-5px 1px 7px -5px rgba(0,0,0,0.75);-webkit-box-shadow:-5px 1px 7px -5px rgba(0,0,0,0.75);-moz-box-shadow:-5px 1px 7px -5px rgba(0,0,0,0.75)}.side-icons .inner-side-icon a{height:100%;display:inline-block;width:100%;background:#fff;padding:10px}.side-icons .inner-side-icon a i{font-size:48px}.side-icons .inner-side-icon a i.fa-whatsapp{font-size:48px;color:#4fce5d}.side-icons .inner-side-icon:first-child a{border-bottom:1px solid #d7d7d7}.zoom-img{text-align:center;position:relative;overflow:hidden;margin-bottom:30px}.zoom-img a img{-webkit-transform:translateZ(0);-moz-transform:translateZ(0);transform:translateZ(0)}.actions{position:absolute;bottom:1px;width:50px;left:-50px;z-index:9;overflow:hidden;bottom:82px}.actions div[class^="ul-"]{width:50px;height:50px;background:#fff;text-align:center;display:block;line-height:50px}.actions div.ul-action-link a::before{content:"\f101";font-family:"FontAwesome";font-size:20px}.actions div.ul-call-us a::before{content:"\f098";font-family:"FontAwesome";font-size:14px}.actions div.ul-whats-app a::before{content:"\f232";font-family:"FontAwesome";font-size:20px}.actions div.ul-contact-us a::before{content:"\f0e6";font-family:"FontAwesome";font-size:20px}.bg-transparent{background:transperent!important;position:absolute}.display-prop1{display:none}@media (max-width:1200px){.display-prop1{display:block}.display-prop{display:none}}@media (max-width:1200px){.bg-transparent{position:relative}}
    /*bootstrap*/
    :root{--blue:#007bff;--indigo:#6610f2;--purple:#6f42c1;--pink:#e83e8c;--red:#dc3545;--orange:#fd7e14;--yellow:#ffc107;--green:#28a745;--teal:#20c997;--cyan:#17a2b8;--white:#fff;--gray:#6c757d;--gray-dark:#343a40;--primary:#007bff;--secondary:#6c757d;--success:#28a745;--info:#17a2b8;--warning:#ffc107;--danger:#dc3545;--light:#f8f9fa;--dark:#343a40;--breakpoint-xs:0;--breakpoint-sm:576px;--breakpoint-md:768px;--breakpoint-lg:992px;--breakpoint-xl:1200px;--font-family-sans-serif:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";--font-family-monospace:SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace}*,::after,::before{box-sizing:border-box}html{font-family:sans-serif;line-height:1.15;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;-ms-overflow-style:scrollbar}@-ms-viewport{width:device-width}header,nav,section{display:block}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";font-size:1rem;font-weight:400;line-height:1.5;color:#212529;text-align:left;background-color:#fff}h1,h4,h6{margin-top:0;margin-bottom:.5rem}p{margin-top:0;margin-bottom:1rem}ul{margin-top:0;margin-bottom:1rem}a{color:#007bff;text-decoration:none;background-color:transparent;-webkit-text-decoration-skip:objects}a:hover{color:#0056b3;text-decoration:underline}img{vertical-align:middle;border-style:none}svg{overflow:hidden;vertical-align:middle}label{display:inline-block;margin-bottom:.5rem}input{margin:0;font-family:inherit;font-size:inherit;line-height:inherit}input{overflow:visible}input[type=checkbox]{box-sizing:border-box;padding:0}::-webkit-file-upload-button{font:inherit;-webkit-appearance:button}h1,h4,h6{margin-bottom:.5rem;font-family:inherit;font-weight:500;line-height:1.2;color:inherit}h1{font-size:2.5rem}h4{font-size:1.5rem}h6{font-size:1rem}.img-fluid{max-width:100%;height:auto}.container{width:100%;padding-right:15px;padding-left:15px;margin-right:auto;margin-left:auto}@media (min-width:576px){.container{max-width:540px}}@media (min-width:768px){.container{max-width:720px}}@media (min-width:992px){.container{max-width:960px}}@media (min-width:1200px){.container{max-width:1170px}}.row{display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap;margin-right:-15px;margin-left:-15px}.col-lg-12,.col-lg-4,.col-md-4,.col-sm-6{position:relative;width:100%;min-height:1px;padding-right:15px;padding-left:15px}@media (min-width:576px){.col-sm-6{-ms-flex:0 0 50%;flex:0 0 50%;max-width:50%}}@media (min-width:768px){.col-md-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}}@media (min-width:992px){.col-lg-4{-ms-flex:0 0 33.333333%;flex:0 0 33.333333%;max-width:33.333333%}.col-lg-12{-ms-flex:0 0 100%;flex:0 0 100%;max-width:100%}}.dropdown{position:relative}.carousel{position:relative}.carousel-inner{position:relative;width:100%;overflow:hidden}.carousel-item{position:relative;display:none;-ms-flex-align:center;align-items:center;width:100%;-webkit-backface-visibility:hidden;backface-visibility:hidden;-webkit-perspective:1000px;perspective:1000px}.carousel-item.active{display:block}.carousel-fade .carousel-item{opacity:0}.carousel-fade .carousel-item.active{opacity:1}.carousel-fade .carousel-item.active{-webkit-transform:translateX(0);transform:translateX(0)}@supports ((-webkit-transform-style:preserve-3d) or (transform-style:preserve-3d)){.carousel-fade .carousel-item.active{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}}.carousel-control-next,.carousel-control-prev{position:absolute;top:0;bottom:0;display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:center;justify-content:center;width:15%;color:#fff;text-align:center;opacity:.5}.carousel-control-prev:hover{color:#fff;text-decoration:none;outline:0;opacity:.9}.carousel-control-prev{left:0}.carousel-control-next{right:0}.carousel-control-next-icon,.carousel-control-prev-icon{display:inline-block;width:20px;height:20px;background:transparent no-repeat center center;background-size:100% 100%}.carousel-control-prev-icon{background-image:url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M5.25 0l-4 4 4 4 1.5-1.5-2.5-2.5 2.5-2.5-1.5-1.5z'/%3E%3C/svg%3E")}.carousel-control-next-icon{background-image:url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%23fff' viewBox='0 0 8 8'%3E%3Cpath d='M2.75 0l-1.5 1.5 2.5 2.5-2.5 2.5 1.5 1.5 4-4-4-4z'/%3E%3C/svg%3E")}.bg-transparent{background-color:transparent!important}.clearfix::after{display:block;clear:both;content:""}.d-block{display:block!important}.sr-only{position:absolute;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.w-100{width:100%!important}.text-center{text-align:center!important}
    /*responsive*/
    @media only screen and (min-width:1200px){#site-header-menu #site-navigation{position:relative;height:117px;line-height:117px}#site-header-menu #site-navigation .menu{float:right}#site-header-menu #site-navigation .menu{position:relative}#site-header-menu #site-navigation .menu:before{display:block;content:"";position:absolute;height:30px;width:1px;right:-2px;top:50%;margin-top:-13px;background-color:rgba(255,255,255,0.08)}#site-header-menu #site-navigation .menu>ul{margin:0px;padding:0px}#site-header-menu #site-navigation .menu>ul>li{display:inline-block;position:relative}#site-header-menu #site-navigation .menu>ul>li>a{display:block;margin:0px 17px 0px 17px;position:relative;z-index:1;line-height:117px!important;font-weight:600;text-transform:capitalize;font-size:15px}#site-header-menu #site-navigation .menu>ul>li>a:before{width:100%;height:2px;display:block;opacity:0;position:absolute;content:"";opacity:0;top:81px;margin:0 auto -2px;left:0}#site-header-menu #site-navigation .menu>ul>li>a{color:#fff!important}#site-header-menu #site-navigation .menu>ul>li.active>a:before{opacity:1;top:76px;background:#fff!important}.ttm-header-style-classic #site-header-menu #site-navigation,.ttm-header-style-classic .site-branding{height:105px;line-height:105px!important}.ttm-header-style-classic #site-header-menu #site-navigation .menu>ul>li>a{height:105px;line-height:105px!important}}@media all and (max-width:1199px){header .container{max-width:100%}#site-header-menu #site-navigation .menu{display:none}.site-branding{float:none;text-align:center}.site-branding{display:block;position:absolute;top:0;left:0;width:100%;background:#fff}.site-header-menu-inner.ttm-stickable-header{width:auto;display:block;position:relative}#site-navigation .menu>ul{position:absolute;padding:10px 20px;box-shadow:rgba(0,0,0,0.12) 3px 3px 15px;border-top:3px solid;z-index:100;width:100%;top:105px;background-color:#fff;margin:0}#site-navigation .menu>ul li:not(:last-child){border-bottom:1px solid rgba(80,87,103,0.15)}#site-header-menu #site-navigation .menu li,#site-header-menu #site-navigation .menu>ul>li{display:block}#site-header-menu #site-navigation .menu ul li a{display:block;padding:15px 0px;text-decoration:none;line-height:18px!important;height:auto;line-height:18px;font-weight:500;font-size:16px}#site-header-menu .site-navigation{position:relative}#site-header-menu #site-navigation .menu ul li a{color:rgba(80,87,103,1)}.ttm-menu-toggle{position:relative;height:30px;width:30px;float:left;top:10px;margin-left:-10px}.ttm-menu-toggle label{position:absolute;z-index:99;height:100%;width:100%;top:43px;left:15px;margin:0}.ttm-menu-toggle .toggle-block{position:absolute;height:2px;width:100%;padding:0;background-color:#ecf0f1}.ttm-header-style-classic .ttm-menu-toggle .toggle-block{background-color:#262626}.ttm-menu-toggle .toggle-blocks-1{position:relative;float:left}.ttm-header-style-classic .ttm-stickable-header-w{height:105px}.ttm-menu-toggle .toggle-blocks-2{position:relative;float:left;margin-top:6px}.ttm-menu-toggle .toggle-blocks-3{position:relative;float:left;margin-top:6px}#site-header-menu #site-navigation .menu{clear:both;min-width:inherit;float:none}#site-header-menu #site-navigation .menu{overflow:hidden;max-height:0;background-color:#fff}}@media (max-width:991px){.section-title{margin-bottom:30px}}@media (max-width:390px){.site-branding img{max-height:50px}}
</style>
<style>
@media (max-width: 1199px){
.ttm-menu-toggle label {
    cursor: pointer;
    position: absolute;
    z-index: 99;
    height: 100%;
    width: 100%;
    top: -50px !important;
    left: -3px !important;
    margin: 0;
}
}
.owl-nav button{
    background: #b4cd29;
    font-size:20px;
        margin-top: 20px;
}
.testimonial-item {
   
    height: 451px;
}
</style>

<link rel=“canonical” href=“https://www.bambooevents.co.in” />



<style>
    .featured-thumbnail img{
        width: 100%;
    }
        .addReadMore.showlesscontent .SecSec,
    .addReadMore.showlesscontent .readLess {
        display: none;
    }

    .addReadMore.showmorecontent .readMore {
        display: none;
    }

    .addReadMore .readMore,
    .addReadMore .readLess {
        font-weight: bold;
        margin-left: 2px;
        color: #b3cc27;
        cursor: pointer;
    }

    .addReadMoreWrapTxt.showmorecontent .SecSec,
    .addReadMoreWrapTxt.showmorecontent .readLess {
        display: block;
    }
</style>

 <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->

<!-- favicon icon -->
<link rel="shortcut icon" href="images/favicon.png" />
<!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<!-- animate -->
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<!-- owl-carousel -->
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<!-- fontawesome -->
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<!-- themify -->
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<!-- flaticon -->
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<!-- REVOLUTION LAYERS STYLES -->
<link rel="stylesheet" type="text/css" href="revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="revolution/css/settings.css">

<!-- prettyphoto -->
<link rel="stylesheet" type="text/css"             
href="css/prettyPhoto.css">

<!-- shortcodes -->
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>

<!-- main -->
<link rel="stylesheet" type="text/css" href="css/main.css"/>

<!-- responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css"/>
</head>

<body> 

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P6N5G4L"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<!--page start-->
        <!--header start-->
        
     <div class="page">
<header id="masthead" class="header ttm-header-style-classic">
            <!--topbar start-->
            <!--<div class="ttm-topbar-wrapper ttm-bgcolor-skincolor ttm-textcolor-white clearfix bg-white top-header">-->
            <!--    <div class="container">-->
            <!--        <div class="ttm-topbar-content">-->
            <!--            <div class="topbar-right text-left">-->
            <!--                <div class="ttm-social-links-wrapper list-inline" style="padding:0px;">-->
            <!--                    <ul class="social-icons">-->
            <!--                        <li><a href="#" class="fb"><i class="fa fa-facebook"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="tw"><i class="fa fa-twitter"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="pi"><i class="fa fa-pinterest"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="ln"><i class="fa fa-linkedin"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="in"><i class="fa fa-instagram"></i></a>-->
            <!--                        </li>-->
            <!--                    </ul>-->
            <!--                </div>-->
            <!--                <ul class="top-contact float-right">-->
            <!--                    <a href="#" class="float-left mail-ixon"><i class="fa fa-envelope"></i>&nbsp; info@bambooevents.com</a>-->
            <!--                    <li class="list-inline-item"><strong><a href="tel:+91 99949 24984"><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                 <li class="list-inline-item"><a href="tel:+91 99949 24984"><strong><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                </ul>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            <!--topbar end-->
            <!-- ttm-header-wrap -->
            <div id="ttm-header-wrap">
                <!-- ttm-stickable-header-w -->
                <div id="ttm-stickable-header-w" class="ttm-stickable-header-w ttm-bgcolor-white clearfix bg-transparent">
                    <div id="site-header-menu" class="site-header-menu">
                        <div class="site-header-menu-inner ttm-stickable-header">
                              <div class="container">
                                <div class="site-header-main">
                                    <!-- site-branding -->
                                    <div class="site-branding">
                                        <a class="home-link display-prop" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo-white.png" alt="logo" width="218" height="100">
                                        </a>
                                        <a class="home-link display-prop1" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo1.webp" alt="logo" width="218" height="100">
                                        </a>
                                    </div><!-- site-branding end -->
                                    <!--site-navigation -->
                                    <div id="site-navigation" class="site-navigation">
                                        <!-- header-icins -->
                                        <div class="ttm-menu-toggle">
                                            <input type="checkbox" id="menu-toggle-form" />
                                            <label for="menu-toggle-form" class="ttm-menu-toggle-block">
                                                <span class="toggle-block toggle-blocks-1"></span>
                                                <span class="toggle-block toggle-blocks-2"></span>
                                                <span class="toggle-block toggle-blocks-3"></span>
                                            </label>
                                        </div>
                                        <nav id="menu" class="menu">
                                            <ul class="dropdown">
                                                <li class="active"><a href="index.php">Home</a></li>
                                                <li class=""><a href="top-event-management-companies.php">About Us</a></li>
                                                <li class=""><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                                <li class=""><a href="top-event-management-gallery.php">Gallery</a></li>
                                                <li class=""><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                                <li class=""><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                                <li class=""><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <!--site-navigation end-->
                                </div>
                            </div>
                        </div>
                    </div><!--ttm-header-wrap end -->
                    
                </div>
            </div><!-- ttm-header-wrap END -->
                    </header>
        <!--header end-->        <!--header end-->        
        <section class="slider-section">
          <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/slides/bannersss9.webp" alt="First slide"  width="1349" height="600"  class="mobile_banner" >
    </div>
    <!--<div class="carousel-item">-->
    <!--  <img class="d-block w-100" src="images/slides/birthday-slide1.webp" alt="Second slide">-->
    <!--</div>-->
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/birthday-slide2.webp" alt="Second slide" width="1349" height="600" class="lazyload mobile_banner" loading="lazy" >
    </div>
    <!--<div class="carousel-item">-->
    <!--  <img class="d-block w-100" src="images/slides/birthday-slide3.webp" alt="Second slide">-->
    <!--</div>-->
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/corporate-slide1.webp" alt="Second slide" width="1349" height="600" class="lazyload mobile_banner" loading="lazy" >
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/corporate-slidess2.webp" alt="Second slide" width="1349" height="600" class="lazyload mobile_banner" loading="lazy" >
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/corporate-slide3.webp" alt="Second slide" width="1349" height="600" class="lazyload mobile_banner r" loading="lazy">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/sangeet-slidess1 .webp" alt="Second slide" width="1349" height="600" class="lazyload mobile_banner" loading="lazy">
    </div> 
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/sangeet-slide2.webp" alt="Second slide" width="1349" height="600" class="lazyload mobile_banner" loading="lazy">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/wedding-slide1.webp" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/wedding-slide2.webp" alt="Second slide" width="1349" height="600" class="lazyload mobile_banner" loading="lazy">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/banner2.webp" alt="Second slide" width="1349" height="600" class="lazyload mobile_banner" loading="lazy">
    </div>
    
    <div class="carousel-item">
      <img class="d-block w-100" src="images/slides/banner8.webp" alt="Third slide" width="1349"height="600" class="lazyload mobile_banner" loading="lazy">
    </div>
    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>                  <!--site-main start-->
        <div class="site-main">
            
           <section class="wide-tb-120" style="padding-top: 10px;">
            <div class="container">
                <div class="col-lg-12 text-center">
                            <div class=" section-title clearfix">
                                <!--<h4>best event management services</h4>-->
                                <h1 class="title">Bamboo Events Planning and Decor </h1>
                                <div class="title-img">
                                    <img src="images/ds-1.webp" alt="puberty function event organizer in coimbatore" width="87" height="23">
                                </div>
                            </div>
                        </div>
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="event-text">
                    <a href="wedding-planner-coimbatore-india.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Wedding Planner</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="wedding-planner-coimbatore-india.php"><img class="img-fluid" src="images/new/wedding2.webp" alt="wedding Planner In Coimbatore" width="360" height="400"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="wedding-planner-coimbatore-india.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Wedding Planner"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>   
                </div>                 
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="event-text">
                        <a href="corporate-event-management-companies.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Corporate Events</h4></a>
                    </div> 
                    <div class="zoom-img">
                        <a href="corporate-event-management-companies.php"><img class="img-fluid" src="images/new/corporate2.webp" alt="corporate event planner in coimbatore" width="360" height="400"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="corporate-event-management-companies.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Corporate Events"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>                 
                </div>                 
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="event-text">
                    <a href="birthday-party-event-management.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Birthday Party</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="birthday-party-event-management.php"><img class="img-fluid" src="images/new/birthday2.webp" alt="birthday party planner in coimbatore" width="360" height="400"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="birthday-party-event-management.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Birthday Party"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>                 
                </div>                 
                </div> 
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="event-text">
                    <a href="housewarmig-functions-organizer.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Housewarming</h4></a>
                    </div> 
                    <div class="zoom-img">
                        <a href="housewarmig-functions-organizer.php"><img class="img-fluid" src="images/house-warming.webp" alt="housewarming function planner in coimbatore" width="360" height="400"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="housewarmig-functions-organizer.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Housewarming"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>                
                </div>                 
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="event-text">
                    <a href="puberty-event-function-organizer.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Puberty Function</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="puberty-event-function-organizer.php"><img class="img-fluid" src="images/puberty-functions.webp" alt="puberty function planner in coimbatore" width="360" height="400"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="puberty-event-function-organizer.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Puberty Function"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>                 
                </div>                 
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="event-text">
                    <a href="engagement-planner-coimbatore.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Engagement</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="engagement-planner-coimbatore.php"><img class="img-fluid" src="images/engagement.webp" alt="engagement event planner in coimbatore" width="360" height="400"></a>
                    <div class="actions">
                        <div class="ul-action-link"><a href="engagement-planner-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Engagement"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                </div>                 
                </div> 
                <div class="col-md-12 text-center">
                    <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-black mt-50" href="event-managements-services-coimbatore.php">All Service</a>
                </div>                
            </div>
            <!--site-main-->
        

            </div>
        </section>
        <!-- Most Popular Categories End -->
          <!-- feature area start -->
    <!--<div class="feature-area ptb--100 bg-light">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--              <div class="col-lg-12 text-center">-->
    <!--                        <div class=" section-title clearfix">-->
    <!--                            <h4>Customised Event Decor Services </h4>-->
    <!--                            <h2 class="title">How to Plan Your Wedding with Bamboo Events?</h2>-->
    <!--                            <div class="title-img">-->
    <!--                                <img src="images/ds-1.webp" alt="engagement event organizer in coimbatore">-->
    <!--                            </div>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--            <div class="service-type">-->
    <!--          <div class="service-catagari">-->
    <!--                <ul>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-restaurant"></i>-->
    <!--                            <span class="text">Caterers</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-ballons"></i>-->
    <!--                            <span class="text">Decor & Florists</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-calendar"></i>-->
    <!--                            <span class="text">Event Planner</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-makeup"></i>-->
    <!--                            <span class="text">Make-up and Hair</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-wedding-anniversary-january-calendar-page"></i>-->
    <!--                            <span class="text">Wedding Cards</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-mehndi"></i>-->
    <!--                            <span class="text">Mehandi</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-wedding-cake"></i>-->
    <!--                            <span class="text">Cakes</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-dj-1"></i>-->
    <!--                            <span class="text">DJ</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-camera"></i>-->
    <!--                            <span class="text">Photographers</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-stage"></i>-->
    <!--                            <span class="text">Entertainment</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-gift"></i>-->
    <!--                            <span class="text">Goody Bags / Gifts</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-exhibition-1"></i>-->
    <!--                            <span class="text">Accommodation</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-disco"></i>-->
    <!--                            <span class="text">Audio & Lighting</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-confetti"></i>-->
    <!--                            <span class="text">Magic Show</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-wedding-car"></i>-->
    <!--                            <span class="text">Vehicle Arrangement</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-pooja"></i>-->
    <!--                            <span class="text">Pooja Pandit</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-dj"></i>-->
    <!--                            <span class="text">Orchestra</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-female-flamenco-dancer"></i>-->
    <!--                            <span class="text">Dance</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-drum-1"></i>-->
    <!--                            <span class="text">Mela Vaathiyam</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                    <li>-->
    <!--                        <a href="#">-->
    <!--                            <i class="flaticon flaticon-dance-1"></i>-->
    <!--                            <span class="text">Wedding Music Artists</span>-->
    <!--                        </a>-->
    <!--                    </li>-->
    <!--                </ul>-->
            
    <!--            </div>-->
    <!--        </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!-- feature area end -->
                <!-- fid-section -->
            <section class="ttm-row fid-section count-bg clearfix">
                <div class="container">
                    <div class="row">
                        <!--<div class="col-md-6 col-sm-6 col-lg-3 counter-wrap">-->
                            <!--ttm-fid-content-->
                        <!--    <div class="ttm-fid text-center">-->
                        <!--        <div class="ttm-fid-icon-wrapper ttm-icon ttm-icon_element-color-white ttm-icon_element-size-md">-->
                        <!--            <i class="fa fa-calendar-check-o "></i>-->
                        <!--        </div>-->
                        <!--        <div class="ttm-fid-contents">-->
                        <!--            <h4><span   data-appear-animation = "animateDigits"-->
                        <!--                        data-from             = "0"-->
                        <!--                        data-to               = "12"-->
                        <!--                        data-interval         = "10"-->
                        <!--                        data-before           = ""-->
                        <!--                        data-before-style     = "sup"-->
                        <!--                        data-after            = ""-->
                        <!--                        data-after-style      = "sub"-->
                        <!--                    >878-->
                        <!--                </span>-->
                        <!--            </h4>-->
                        <!--            <h3 class="ttm-fid-title"><span>EXPERIENCE<br></span></h3>-->
                        <!--        </div><!-- ttm-fld-contents end -->
                        <!--    </div>-->
                        <!--</div>-->
                         <div class="col-md-6 col-sm-6 col-lg-3 counter-wrap">
                            <div class="ttm-fid text-center">
                                <div class="ttm-fid-icon-wrapper ttm-icon ttm-icon_element-color-white ttm-icon_element-size-md">
                                     <i class="fa fa-calendar-check-o "></i>
                                </div>
                                <div class="ttm-fid-contents">
                                    <h4><span class="number">12
                                        </span>
                                    </h4>
                                    <h3 class="ttm-fid-title"><span>EXPERIENCE<br></span></h3>
                                </div><!-- ttm-fld-contents end -->
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3 counter-wrap">
                            <div class="ttm-fid text-center">
                                <div class="ttm-fid-icon-wrapper ttm-icon ttm-icon_element-color-white ttm-icon_element-size-md">
                                    <i class="flaticon flaticon-wedding"></i>
                                </div>
                                <div class="ttm-fid-contents">
                                    <h4><span class="number" >175  
                                            
                                        </span>
                                    </h4>
                                    <h3 class="ttm-fid-title"><span>WEDDING EVENT<br></span></h3>
                                </div><!-- ttm-fld-contents end -->
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3 counter-wrap">
                            <!--ttm-fid-content-->
                            <div class="ttm-fid text-center">
                                <div class="ttm-fid-icon-wrapper ttm-icon ttm-icon_element-color-white ttm-icon_element-size-md">
                                    <i class="flaticon flaticon-cheers"></i>
                                </div>
                                <div class="ttm-fid-contents">
                                    <h4><span class="number">878
                                        </span>
                                    </h4>
                                    <h3 class="ttm-fid-title"><span>CORPORATE EVENT<br></span></h3>
                                </div><!-- ttm-fld-contents end-->
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-lg-3 counter-wrap">
                            <!--ttm-fid-content-->
                            <div class="ttm-fid text-center">
                                <div class="ttm-fid-icon-wrapper ttm-icon ttm-icon_element-color-white ttm-icon_element-size-md">
                                    <!--<i class="ti ti-face-smile"></i>-->
                                    <i class="flaticon flaticon-couple"></i>
                                </div>
                                <div class="ttm-fid-contents">
                                    <h4><span class="number">125
                                        </span>
                                    </h4>
                                    <h3 class="ttm-fid-title"><span>HAPPY CLIENTS<br></span></h3>
                                </div><!-- ttm-fld-contents end-->
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- fid-section end -->
            <!--testimonial-->
          
            <!--End testimonial-->
           
      <!-- gallery-section2 start -->
      <!--      <section class="ttm-row gallery-section2 clearfix">-->
      <!--          <div class="container">-->
      <!--              <div class="row text-center">-->
      <!--                  <div class="col-lg-12">-->
      <!--                      <div class=" section-title clearfix">-->
      <!--                          <h4>Gallery</h4>-->
      <!--                          <h3 class="title">Bamboo Event's Gallery</h3>-->
      <!--                          <div class="title-img">-->
      <!--                              <img src="images/ds-1.webp" alt="engagement organizer in coimbatore">-->
      <!--                          </div>-->
      <!--                      </div>-->
      <!--                  </div>-->
      <!--              </div>-->
      <!--              <div class="row multi-columns-row ttm-boxes-spacing-0px">-->
      <!--                  <div class="ttm-box-col-wrapper col-lg-8 col-md-8">-->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-3.jpg" alt="baby naming ceremony event management in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Autue Art Gallery Opening" href="images/gallery/gallery-3.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-search"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-02.html">Autue Art Gallery Opening</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Private Party</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                  </div>-->
      <!--                  <div class="ttm-box-col-wrapper col-lg-4 col-md-4">-->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-1.jpg" alt="baby shower event organizer in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Grand Despa Events" href="images/gallery/gallery-1.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-search"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-02.html">Grand Despa Events</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Birthdays</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                  </div>-->
      <!--                  <div class="ttm-box-col-wrapper col-lg-3 col-md-3">-->
      <!--                       featured-item -->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-1.jpg" alt="anniversary event management in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Divqi Holiday Party" href="images/gallery/gallery-1.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-search"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-02.html">Divqi Holiday Party</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Corporate</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                       featured-item -->
      <!--                  </div>-->
      <!--                  <div class="ttm-box-col-wrapper col-lg-6 col-md-6">-->
      <!--                       featured-item -->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-2.jpg" alt="sangeet and mehendi event management in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Kids Birthday Party" href="images/gallery/gallery-2.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-search"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-02.html">Kids Birthday Party</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Private Party</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                       featured-item -->
      <!--                  </div>-->
      <!--                  <div class="ttm-box-col-wrapper col-lg-3 col-md-3">-->
      <!--                       featured-item -->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-1.jpg" alt="sangeet and mehendi event planner in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Steven and Sofia Wedding" href="images/gallery/gallery-1.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-control-play"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-03.html">Steven and Sofia Wedding</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Engagement</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                       featured-item -->
      <!--                  </div>-->
      <!--                  <div class="ttm-box-col-wrapper col-lg-4 col-md-4">-->
      <!--                       featured-item -->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-1.jpg" alt="sangeet and mehendi event organizer in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Helen Birthday Party" href="images/gallery/gallery-1.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-control-play"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-02.html">Helen Birthday Party</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Corporate</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                       featured-item -->
      <!--                  </div>-->
      <!--                  <div class="ttm-box-col-wrapper col-lg-8 col-md-8">-->
      <!--                       featured-item -->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-3.jpg" alt="college alumni event management in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Helen Birthday Party" href="images/gallery/gallery-3.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-control-play"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-02.html">Helen Birthday Party</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Corporate</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                       featured-item -->
      <!--                  </div>-->
      <!--                   <div class="ttm-box-col-wrapper col-lg-3 col-md-3">-->
      <!--                       featured-item -->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-1.jpg" alt="college alumni event organizer in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Divqi Holiday Party" href="images/gallery/gallery-1.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-search"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-02.html">Divqi Holiday Party</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Corporate</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                       featured-item -->
      <!--                  </div>-->
      <!--                  <div class="ttm-box-col-wrapper col-lg-6 col-md-6">-->
      <!--                       featured-item -->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-2.jpg" alt="exhibition stall management in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Kids Birthday Party" href="images/gallery/gallery-2.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-search"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-02.html">Kids Birthday Party</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Private Party</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                       featured-item -->
      <!--                  </div>-->
      <!--                  <div class="ttm-box-col-wrapper col-lg-3 col-md-3">-->
      <!--                       featured-item -->
      <!--                      <div class="featured-imagebox featured-imagebox-portfolio">-->
      <!--                           featured-thumbnail-->
      <!--                          <div class="featured-thumbnail">-->
      <!--                              <a href="#"> <img class="img-fluid" src="images/gallery/gallery-1.jpg" alt="exhibition stall organizer in coimbatore"></a>-->
      <!--                          </div><!-- featured-thumbnail END-->
      <!--                           ttm-box-view-overlay -->
      <!--                          <div class="ttm-box-view-overlay">-->
      <!--                              <div class="ttm-media-link">-->
      <!--                                  <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Steven and Sofia Wedding" href="images/gallery/gallery-1.jpg" data-rel="prettyPhoto">-->
      <!--                                      <i class="ti ti-control-play"></i>-->
      <!--                                  </a>-->
      <!--                              </div>-->
      <!--                              <div class="featured-content featured-content-portfolio">-->
      <!--                                  <div class="featured-title">-->
      <!--                                      <h5><a href="portfolio-details-03.html">Steven and Sofia Wedding</a></h5>-->
      <!--                                  </div>-->
      <!--                                  <span class="category">-->
      <!--                                      <a href="#">Engagement</a>-->
      <!--                                  </span>-->
      <!--                              </div>-->
      <!--                          </div><!-- ttm-box-view-overlay end-->
      <!--                      </div>-->
      <!--                       featured-item -->
      <!--                  </div>-->
      <!--              </div><!-- row end -->
      <!--              <div class="row">-->
      <!--                  <div class="col-md-12 text-center">-->
      <!--                      <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-black mt-50" href="#">View More Gallery</a>-->
      <!--                  </div>-->
      <!--              </div>-->
      <!--          </div>-->
      <!--      </section>-->
            <!--gallery-section2 end-->
            <!--site-main-->
        <!--<div class="site-main">
            <section class="ttm-row gallery-page-section" style = "padding-top :50px" >
                <div class="container">
                    <div class="row">
                        <div class="row text-center">
                        <div class="col-lg-12">
                            <div class="ttm-tabs style2" data-effect="fadeIn">
                                
      
                                 <div class=" section-title clearfix">
                                <h4>Gallery</h4>
                                <h3 class="title">Bamboo Event's Gallery</h3>
                                <div class="title-img">
                                    <img src="images/ds-1.webp" alt="house warming function planner In coimbatore">
                                </div>
                                </div>
                                </div>
      
                                <!--<ul class="tabs clearfix">-->
                                <!--    <li class="tab active"><a href="#" class="shape-round"> All </a></li>-->
                                <!--    <li class="tab"><a href="#" class="shape-round">Private Party</a></li>-->
                                <!--    <li class="tab"><a href="#" class="shape-round">Birthdays</a></li>-->
                                <!--    <li class="tab"><a href="#" class="shape-round">Corporate</a></li>-->
                                <!--    <li class="tab"><a href="#" class="shape-round">Engagement</a></li>-->
                                <!--    <li class="tab"><a href="#" class="shape-round">Weddings</a></li>-->
                                <!--</ul><!-- flat-tab end -->
                            <!--    <div class="content-tab">
                                    <!-- content-inner -->
                            <!--        <div class="content-inner active">
                            <!--            <div class="row pt-10  multi-columns-row ttm-boxes-spacing-0px  ">
                                            <div class="ttm-box-col-wrapper col-lg-4 col-md-4">
                                                <!-- featured-imagebox -->
                               <!--                 <div class="featured-imagebox featured-imagebox-portfolio">
                                                    <!-- featured-thumbnail-->
                                    <!--                <div class="featured-thumbnail">
                                     <!--                   <a href="#"><img class="img-fluid" src="images/gallery/gallery1.webp" alt="birthday party organizer In coimbatore"></a>
                                                    </div><!-- featured-thumbnail END-->
                                                    <!-- ttm-box-view-overlay -->
                                                    <!--<div class="ttm-box-view-overlay">-->
                                                    <!--    <div class="ttm-media-link">-->
                                                    <!--        <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Autue Art Gallery Opening" href="images/gallery/gallery1.jpg" data-rel="prettyPhoto">-->
                                                    <!--            <i class="ti ti-search"></i>-->
                                                    <!--        </a>-->
                                                    <!--    </div>-->
                                                        <!--<div class="featured-content featured-content-portfolio">-->
                                                        <!--    <div class="featured-title">-->
                                                        <!--        <h5><a href="portfolio-details-02.html">Autue Art Gallery Opening</a></h5>-->
                                                        <!--    </div>-->
                                                        <!--    <span class="category">-->
                                                        <!--        <a href="private-party.html">Private Party</a>-->
                                                        <!--    </span>-->
                                                        <!--</div>-->
                                                    <!--</div><!-- ttm-box-view-overlay end-->
                                    <!--            </div><!-- featured-item -->
                                    <!--        </div>
                                            <div class="ttm-box-col-wrapper col-lg-8 col-md-8">
                                                <!-- featured-imagebox -->
                                    <!--            <div class="featured-imagebox featured-imagebox-portfolio">
                                                    <!-- featured-thumbnail-->
                                     <!--               <div class="featured-thumbnail">
                                                        <a href="#"> <img class="img-fluid" src="images/gallery/gallery3.webp" alt="engagement event organizer in ooty"></a>
                                                    </div><!-- featured-thumbnail END-->
                                                    <!-- ttm-box-view-overlay -->
                                                    <!--<div class="ttm-box-view-overlay">-->
                                                    <!--    <div class="ttm-media-link">-->
                                                    <!--        <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Grand Despa Events" href="images/gallery/gallery-2.jpg" data-rel="prettyPhoto">-->
                                                    <!--            <i class="ti ti-search"></i>-->
                                                    <!--        </a>-->
                                                    <!--    </div>-->
                                                    <!--    <div class="featured-content featured-content-portfolio">-->
                                                    <!--        <div class="featured-title">-->
                                                    <!--            <h5><a href="portfolio-details-02.html">Grand Despa Events</a></h5>-->
                                                    <!--        </div>-->
                                                    <!--        <span class="category">-->
                                                    <!--            <a href="private-party.html">Birthdays Party</a>-->
                                                    <!--        </span>-->
                                                    <!--    </div>-->
                                                    <!--</div><!-- ttm-box-view-overlay end-->
                                     <!--           </div><!-- featured-item -->
                                    <!--        </div>
                                            
                                   <!--         <div class="ttm-box-col-wrapper col-lg-3 col-md-3">
                                                <!-- featured-imagebox -->
                                     <!--           <div class="featured-imagebox featured-imagebox-portfolio">
                                                    <!-- featured-thumbnail-->
                                    <!--                <div class="featured-thumbnail">
                                                        <a href="#"> <img class="img-fluid" src="images/gallery/gallery10.webp" alt="birthday party organizer in ooty"></a>
                                                    </div><!-- featured-thumbnail END-->
                                                    <!-- ttm-box-view-overlay -->
                                                 <!--   <div class="ttm-box-view-overlay">
                                                        <div class="ttm-media-link">
                                                            <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Helen Birthday Party" href="images/gallery/gallery-4.jpg" data-rel="prettyPhoto">
                                                                <i class="ti ti-search"></i>
                                                            </a>
                                                        </div>
                                                        <div class="featured-content featured-content-portfolio">
                                                            <div class="featured-title">
                                                                <h5><a href="portfolio-details-02.html">Helen Birthday Party</a></h5>
                                                            </div>
                                                            <span class="category">
                                                                <a href="private-party.html">Private Party</a>
                                                            </span>
                                                        </div>
                                                    </div><!-- ttm-box-view-overlay end-->
                                    <!--            </div><!-- featured-item -->
                                     <!--       </div>
                                            <div class="ttm-box-col-wrapper col-lg-6 col-md-6">
                                                <!-- featured-imagebox -->
                                    <!--            <div class="featured-imagebox featured-imagebox-portfolio">
                                                    <!-- featured-thumbnail-->
                                          <!--          <div class="featured-thumbnail">
                                                        <a href="#"> <img class="img-fluid" src="images/gallery/gallery5.webp" alt="puberty function planner in Ooty"></a>
                                                    </div><!-- featured-thumbnail END-->
                                                    <!-- ttm-box-view-overlay -->
                                                 <!--   <div class="ttm-box-view-overlay">
                                                        <div class="ttm-media-link">
                                                            <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Divqi Holiday Party" href="images/gallery/gallery-3.jpg" data-rel="prettyPhoto">
                                                                <i class="ti ti-search"></i>
                                                            </a>
                                                        </div>
                                                        <div class="featured-content featured-content-portfolio">
                                                            <div class="featured-title">
                                                                <h5><a href="portfolio-details-02.html">Divqi Holiday Party</a></h5>
                                                            </div>
                                                            <span class="category">
                                                                <a href="private-party.html">Corporate</a>
                                                            </span>
                                                        </div>
                                                    </div><!-- ttm-box-view-overlay end-->
                                      <!--          </div><!-- featured-item -->
                                     <!--       </div>
                                            <div class="ttm-box-col-wrapper col-lg-3 col-md-3">
                                                <!-- featured-imagebox -->
                                        <!--        <div class="featured-imagebox featured-imagebox-portfolio">
                                                    <!-- featured-thumbnail-->
                                            <!--        <div class="featured-thumbnail">
                                                        <a href="#"> <img class="img-fluid" src="images/gallery/gallery7.webp" alt="exhibition stall planner in coimbatore"></a>
                                                    </div><!-- featured-thumbnail END-->
                                                    <!-- ttm-box-view-overlay -->
                                                <!--    <div class="ttm-box-view-overlay">
                                                        <div class="ttm-media-link">
                                                            <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Steven and Sofia Wedding" href="images/gallery/gallery-5.jpg" data-rel="prettyPhoto">
                                                                <i class="ti ti-search"></i>
                                                            </a>
                                                        </div>
                                                        <div class="featured-content featured-content-portfolio">
                                                            <div class="featured-title">
                                                                <h5><a href="portfolio-details-03.html">Steven and Sofia Wedding</a></h5>
                                                            </div>
                                                            <span class="category">
                                                                <a href="private-party.html">Engagement</a>,
                                                                <a href="private-party.html">Weddings</a>
                                                            </span>
                                                        </div>
                                                    </div><!-- ttm-box-view-overlay end-->
                                        <!--        </div><!-- featured-item -->
                                      <!--      </div>
                                            <div class="ttm-box-col-wrapper col-lg-4 col-md-6">
                                                <!-- featured-imagebox -->
                                         <!--       <div class="featured-imagebox featured-imagebox-portfolio">
                                                    <!-- featured-thumbnail-->
                                         <!--           <div class="featured-thumbnail">
                                                        <a href="#"> <img class="img-fluid" src="images/gallery/gallery2.webp" alt="Wedding planner In ooty"></a>
                                                    </div><!-- featured-thumbnail END-->
                                                    <!-- ttm-box-view-overlay -->
                                                <!--    <div class="ttm-box-view-overlay">
                                                        <div class="ttm-media-link">
                                                            <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="LightFox Night Party" href="images/gallery/gallery-6.jpg" data-rel="prettyPhoto">
                                                                <i class="ti ti-search"></i>
                                                            </a>
                                                        </div>
                                                        <div class="featured-content featured-content-portfolio">
                                                            <div class="featured-title">
                                                                <h5><a href="portfolio-details-02.html">LightFox Night Party</a></h5>
                                                            </div>
                                                            <span class="category">
                                                                <a href="private-party.html">Birth day</a>
                                                            </span>
                                                        </div>
                                                    </div><!-- ttm-box-view-overlay end-->
                                       <!--         </div><!-- featured-item -->
                                     <!--       </div>
                                            <div class="ttm-box-col-wrapper col-lg-4 col-md-6">
                                                <!-- featured-imagebox -->
                                    <!--            <div class="featured-imagebox featured-imagebox-portfolio">
                                                    <!-- featured-thumbnail-->
                                        <!--            <div class="featured-thumbnail">
                                                        <a href="#"> <img class="img-fluid" src="images/gallery/gallery4.webp" alt="college alumni event Organizer in coimbatore"></a>
                                                    </div><!-- featured-thumbnail END-->
                                                    <!-- ttm-box-view-overlay -->
                                                 <!--   <div class="ttm-box-view-overlay">
                                                        <div class="ttm-media-link">
                                                            <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Kids Birthday Party" href="images/gallery/gallery-9.jpg" data-rel="prettyPhoto">
                                                                <i class="ti ti-search"></i>
                                                            </a>
                                                        </div>
                                                        <div class="featured-content featured-content-portfolio">
                                                            <div class="featured-title">
                                                                <h5><a href="portfolio-details-02.html">Kids Birthday Party</a></h5>
                                                            </div>
                                                            <span class="category">
                                                                <a href="private-party.html">Corporate</a>
                                                            </span>
                                                        </div>
                                                    </div><!-- ttm-box-view-overlay end-->
                                        <!--        </div><!-- featured-item -->
                                   <!--         </div>
                                            <div class="ttm-box-col-wrapper col-lg-4 col-md-6">
                                                <!-- featured-imagebox -->
                                    <!--            <div class="featured-imagebox featured-imagebox-portfolio">
                                                    <!-- featured-thumbnail-->
                                        <!--            <div class="featured-thumbnail">
                                                        <a href="#"> <img class="img-fluid" src="images/gallery/gallery6.webp" alt="sangeet And mehendi event management in coimbatore"></a>
                                                    </div><!-- featured-thumbnail END-->
                                                    <!-- ttm-box-view-overlay -->
                                                <!--    <div class="ttm-box-view-overlay">
                                                        <div class="ttm-media-link">
                                                            <a class="ttm_prettyphoto ttm_image" data-gal="prettyPhoto[gallery1]" title="Halloween Party" href="images/gallery/gallery-7.jpg" data-rel="prettyPhoto">
                                                                <i class="ti ti-search"></i>
                                                            </a>
                                                        </div>
                                                        <div class="featured-content featured-content-portfolio">
                                                            <div class="featured-title">
                                                                <h5><a href="portfolio-details-02.html">Halloween Party</a></h5>
                                                            </div>
                                                            <span class="category">
                                                                <a href="private-party.html">Private Party</a>
                                                            </span>
                                                        </div>
                                                    </div><!-- ttm-box-view-overlay end-->
                                     <!--           </div><!-- featured-item -->
                                      <!--      </div>



                                        </div>
                                    </div><!-- content-inner end-->
                                     
                                    
                           <!--     </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
           
        </div> --><!-- site-main end --> 
        
        
        <!-- testimonial-area -->
            <section class="testimonial-area testimonial-bg pt-110 pb-120">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-12 text-center">
                            <div class=" section-title clearfix">
                                <h4>SEE OUR BEST</h4>
                                <h3 class="title">What People Says About Bamboo Events</h3>
                                <div class="title-img">
                                    <img src="images/ds-1.webp" alt="" width="87" height="23">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id ="owl-carousel" class="row owl-carousel owl-theme">
                            <div class="testimonial-item">
                                <div class="testimonial-quote">
                                    <svg version="1.1" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve">
                                        <g>
                                            <polygon points="0,4 0,28 12,16 12,4" />
                                            <polygon points="20,4 20,28 32,16 32,4" />
                                        </g>
                                    </svg>
                                </div>
                                <div class="testimonial-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="testi-content">
                                    <p class="addReadMore showlesscontent">The best decision we made for our wedding was deciding to work with  bamboo events, they made my big day memorable. our wedding planner Vidhya did an amazing job. She is so organized and professional. If you are looking for a perfect wedding planning company I highly recommend Bamboo events planning and Decor.</p>
                                    <div class="testi-avatar-wrap">
                                        <div class="testi-avatar-img">
                                            <img src="img/images/testi_avatar01.png" alt="">
                                        </div>
                                        <div class="testi-avatar-info">
                                            <h6>Rakesh Rangaraj</h6>
                                            <span>Positive: Quality & Responsiveness</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="testimonial-item">
                                <div class="testimonial-quote">
                                    <svg version="1.1" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve">
                                        <g>
                                            <polygon points="0,4 0,28 12,16 12,4" />
                                            <polygon points="20,4 20,28 32,16 32,4" />
                                        </g>
                                    </svg>
                                </div>
                                <div class="testimonial-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="testi-content">
                                    <p class="addReadMore showlesscontent">Dedication, professionalism, and creativity are the core qualities of Bamboo events.. she understands the clients requirements and mindset very well works hard to deliver it in time and with best output. Will refer her again and again</p>
                                    <div class="testi-avatar-wrap">
                                        <div class="testi-avatar-img">
                                            <img src="img/images/testi_avatar02.png" alt="">
                                        </div>
                                        <div class="testi-avatar-info">
                                            <h6>Srividya Venkataraman</h6>
                                            <span>Positive: Professionalism</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!--                            <div class="testimonial-item">-->
<!--                                <div class="testimonial-quote">-->
<!--                                    <svg version="1.1" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve">-->
<!--                                        <g>-->
<!--                                            <polygon points="0,4 0,28 12,16 12,4" />-->
<!--                                            <polygon points="20,4 20,28 32,16 32,4" />-->
<!--                                        </g>-->
<!--                                    </svg>-->
<!--                                </div>-->
<!--                                <div class="testimonial-rating">-->
<!--                                    <i class="fa fa-star"></i>-->
<!--                                    <i class="fa fa-star"></i>-->
<!--                                    <i class="fa fa-star"></i>-->
<!--                                    <i class="fa fa-star"></i>-->
<!--                                    <i class="fa fa-star"></i>-->
<!--                                </div>-->
<!--                                <div class="testi-content">-->
<!--                                    <p class="addReadMore showlesscontent">Without any hesitation, I will recommend Bamboo Events for any occasion in your family.We decided to have our Daughter's Half Saree Ceremony, in less than 24hours. As we were busy with managing too many things, we forgot to think about the backdrop for my daughter's occasion. At 1PM, we released this and I called up Ms. SreeVidya of Bamboo events asking her to help us. Without hesitation, she accepted this challenge and she scrambled all the workers immediately. At 6PM, the backdrop was ready at our venue. Bamboo events handled the work so professionally that everyone who attended the ceremony was awestruck by the backdrop.  I personally had to thank Ms.SreeVidya for making my daughter's ceremony memorable and grandeur. This kind of work can only be done by a person, if one can get into the shoes of others. In our case she made my daughters ceremony very very memorable. Thank you is a very simple word for Ms.SreeVidya and Bamboo events.-->

<!--பயன்தூக்கார் செய்த உதவி நயன்தூக்கின்-->
<!--நன்மை கடலின் பெரிது. (அறத்துப்பால்)-->

<!--Keep it up and way to go!!</p>-->
<!--                                    <div class="testi-avatar-wrap">-->
<!--                                        <div class="testi-avatar-img">-->
<!--                                            <img src="img/images/testi_avatar03.png" alt="">-->
<!--                                        </div>-->
<!--                                        <div class="testi-avatar-info">-->
<!--                                            <h6>Saravanakumar Ponnuswamy</h6>-->
<!--                                            <span>Positive: Professionalism</span>-->
<!--                                        </div>-->
<!--                                    </div>-->
<!--                                </div>-->
<!--                            </div>-->
                            <div class="testimonial-item">
                                <div class="testimonial-quote">
                                    <svg version="1.1" x="0px" y="0px" viewBox="0 0 32 32" xml:space="preserve">
                                        <g>
                                            <polygon points="0,4 0,28 12,16 12,4" />
                                            <polygon points="20,4 20,28 32,16 32,4" />
                                        </g>
                                    </svg>
                                </div>
                                <div class="testimonial-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                <div class="testi-content">
                                    <p class="addReadMore showlesscontent">Bamboo events planning.. dey are gud in service...I have booked some other event planner..at last moment dey had a issues and canceled..I got a reference about bamboo events..I called them they helped me with in a day they finished all my requirements ..special thanks to...sree vidya ethiraj  she is so reasonable and friendly too..I was fully satisfied with services ...quality vice and price vice..so I highly recommend babmboo events 😃😃😃</p>
                                    <div class="testi-avatar-wrap">
                                        <div class="testi-avatar-img">
                                            <img src="img/images/testi_avatar02.png" alt="">
                                        </div>
                                        <div class="testi-avatar-info">
                                            <h6>Deepu Mithun</h6>
                                            <span>Positive: Professionalism</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <!--<div class="row">-->
                        <!--<div class="col-md-12 text-center">-->
                        <!--    <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-black mt-50" href="#">View More Review</a>-->
                        <!--</div>-->
                    <!--</div>-->
                </div>
            </section>
        <!-- testimonial-area-end -->
        
        <!--footer--> 
        <footer class="footer widget-footer bg-img11 ttm-bgcolor-black ttm-bg ttm-bgimage-yes clearfix">
            <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
            <div class="second-footer">
                <div class="container">
                    <div class="second-footer-inner">
                        <div class="row">
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">Quick Links </h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="top-event-management-companies.php">Why Us</a></li>
                                        <li><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                        <li><a href="top-event-management-gallery.php">Gallery</a></li>
                                        <li><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                        <li><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                        <li><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="engagement-planner-coimbatore.php">Engagement</a></li>
                                        <li><a href="wedding-planner-coimbatore-india.php">Wedding Planner</a></li>
                                        <li><a href="top-best-destination-wedding-planners.php">Destination Wedding</a></li>
                                        <li><a href="corporate-event-management-companies.php">Corporate Events</a></li>
                                        <li><a href="product-launch-event-organizers-chennai.php">Product Launch Events</a></li>
                                        <li><a href="company-award-ceremony-event-planner.php">Company Award Ceremony</a></li>
                                        <li><a href="virtual-online-event-management-organizers.php">Virtual Event Planner</a></li>
                                        <li><a href="corporate-social-event-planner-india.php">Corporate Social Events</a></li>
                                        <li><a href="exhibition-stall-design-fabricators-services.php">Exhibition Stall</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix ">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="birthday-party-event-management.php">Birthday Party</a></li>
                                        <li><a href="housewarmig-functions-organizer.php">Housewarming</a></li>
                                        <li><a href="baby-naming-ceremony-events.php">Baby Naming Ceremony</a></li>
                                        <li><a href="puberty-event-function-organizer.php">Puberty Function</a></li>
                                        <li><a href="bangle-ceremony-event-valaikappu-function.php">Bangle Ceremony</a></li>
                                        <li><a href="sangeet-mehendi-ceremony-coimbatore.php">Sangeet & Mehendi</a></li>
                                        <li><a href="wedding-anniversary-event-planner.php">Anniversary</a></li>
                                        <li><a href="school-college-alumni-event-planners.php">College/School Alumni</a></li>
                                    </ul>
                                    <!--<h4 class="widget-title">Frequent Questions</h4>
                                    <ul class="widget-text">
                                        <li><a href="#">How Can I Set An Event? </a></li>
                                        <li><a href="#">What Venues Do You Use? </a></li>
                                        <li><a href="#">Event Catalogue </a></li>
                                        <li><a href="#">Shipping & Delivery </a></li>
                                        <li><a href="#">What's your dream job? </a></li>
                                    </ul>-->
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix">
                                    <h4 class="widget-title">Contact Us</h4>
                                    <ul class="widget-contact">
                                        <!--<li><i class="fa fa-map-marker"></i>No.45A, Kalluri Nagar,<br>Near Peelamedu Fire Station,<br>Periyar Nagar,<br>Masakalipalayam,<br>Peelamedu,<br>Coimbatore-641004.</li>-->
                                        <li><i class="fa fa-map-marker"></i>No.2, Ground floor,<br>D.J.Nagar,Hopescollage,<br>Near Water Tank,<br>Coimbatore-641 004.</li>
                                        <li><i class="fa fa-envelope-o"></i><a href="mailto:enquiry@bambooevents.co.in">enquiry@bambooevents.co.in</a></li>
                                        <li><a href="tel:+919994924984"><i class="fa fa-phone"></i>+91 99949 24984</li></a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-footer-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-xs-12 ttm-footer2-left">
                            <div class="company-info" style="color: #fff;">
                                  <P>Copyright © 2023 <span style="color: #b4cd29;">Bamboo Events Planning &amp; Decor</span>. All Rights Reserved. Designed By <a href="https://www.xcodefix.com/"target="_blank">Xcodefix</a></P>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xs-12 col-md-4 ttm-footer2-right">
                            <div class="ttm-social-link-wrapper list-inline" style="padding:2px;">
                                <ul class="social-icons">
                                    <ul class="social-icons">
                                    <li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li><a href="https://www.instagram.com/bambooevents_cbe/" class="in"><i class="fa fa-instagram"></i></a>
                                    </li>
                                    <li><a href="https://twitter.com/BambooDecors" class="tw"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    <li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" class="ln"><i class="fa fa-youtube-play"></i></a>
                                    </li>
                                    
                                </ul>
                                    <!--<li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a></li>-->
                                    <!--<li><a href="https://twitter.com/BambooDecors" target="_blank"><i class="fa fa-twitter"></i></a></li>-->
                                    <!--<li><a href="https://www.instagram.com/bambooevents_cbe/" target="_blank"><i class="fa fa-instagram"></i></a></li>-->
                                    <!--<li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" target="_blank"><i class="fa fa-youtube-play"></i></a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
</div>       <div class="side-icons">
    <div class="inner-side-icon">
        <a href="https://wa.me/+919994924984?text=I'm%20interested%20in%20your%20Bamboo%20Events%20Services" target="_blank"><i class="fa fa-whatsapp" style="font-size: 48px;"></i></a> 
    </div>
    <div class="inner-side-icon">
        <a href="tel:+919994924984"><i class="fa fa-phone" style="font-size: 48px;"></i></a>
    </div>
</div>        <!--footer-END-->
</div><!-- page end -->
</section>
    <!--back-to-top start-->
    <a id="totop" href="#top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!--back-to-top end-->



    <!-- Javascript -->
    <!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
   <!-- responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css">
   
    <!-- main -->
    
<link rel="stylesheet" type="text/css" href="css/main.css">



    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js" defer></script>
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/jquery.easing.js"></script> 
    <script src="js/jquery-waypoints.js" defer></script>    
    <script src="js/owl.carousel.js" defer></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/numinate.min6959.js?ver=4.9.3" defer></script>
    <script src="js/main.js"></script>


    <!-- Revolution Slider -->
    <!--<script src="revolution/js/jquery.themepunch.tools.min.js"></script>-->
    <!--<script src="revolution/js/jquery.themepunch.revolution.min.js"></script>-->
    <!--<script src="revolution/js/slider.js"></script>-->

    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->    

    <!--<script src="revolution/js/extensions/revolution.extension.actions.min.js"></script>-->
    <!--<script src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>-->
    <!--<script src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>-->
    <!--<script src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>-->
    <!--<script src="revolution/js/extensions/revolution.extension.migration.min.js"></script>-->
    <!--<script src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>-->
    <!--<script src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>-->
    <!--<script src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>-->
    <!--<script type="text/javascript">-->
   
    <!--</script>-->
    <!-- Javascript end-->
    
    <!--Google Tag Manager -->
<script defer>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
 <!--End Google Tag Manager -->

    
    <script type="application/ld+json" defer>
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Bamboo Events Planning and Decor",
  "url": "https://www.bambooevents.co.in/",
  "logo": "https://www.bambooevents.co.in/images/logo-white.png",
  "sameAs": [
    "https://www.facebook.com/bambooeventsindia/",
    "https://twitter.com/BambooDecors",
    "https://www.instagram.com/bambooevents_cbe/",
    "https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig"
  ]
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Counter-Up/1.0.0/jquery.counterup.min.js" integrity="sha512-d8F1J2kyiRowBB/8/pAWsqUl0wSEOkG5KATkVV4slfblq9VRQ6MyDZVxWl2tWd+mPhuCbpTB4M7uU/x9FlgQ9Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
    $('#owl-carousel').owlCarousel({
    loop: true,
    margin: 30,
    dots: false,
    nav: false,
    items: 2,
    	responsive: {
			0: {
				items: 1
				// nav: true
			},
			480: {
				items: 2,
				nav: false
			},
			768: {
				items: 2,
				// nav: true,
				loop: true
			},
			992: {
				items: 2,
				// nav: true,
				loop: true
			}
		}
})
</script>
<script>
  $(".number").counterUp({time:3000});
</script>

</body>

</html>



