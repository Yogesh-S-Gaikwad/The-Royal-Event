<!DOCTYPE html>
<html lang="en">
<head>
    
    <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->
    
    <script type="application/ld+json">
{
  "@context": "https://schema.org/", 
  "@type": "BreadcrumbList", 
  "itemListElement": [{
    "@type": "ListItem", 
    "position": 1, 
    "name": "Home",
    "item": "https://www.bambooevents.co.in/index.php"  
  },{
    "@type": "ListItem", 
    "position": 2, 
    "name": "Bamboo Events Planning",
    "item": "https://www.bambooevents.co.in/event-managements-services-coimbatore.php"  
  },{
    "@type": "ListItem", 
    "position": 3, 
    "name": "Housewarming Ceremony Planners",
    "item": "https://www.bambooevents.co.in/housewarmig-functions-organizer.php"  
  }]
}
</script>


<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <title>Housewarming Event Planners | Gruhapravesha Event Organizer</title>
<meta name="description" content="We are the best housewarming planner and organizer, offers end-to-end event management services for Housewarming in and around Coimbatore,Tirupur" />


<style>
    .featured-thumbnail img{
        width: 100%;
    }
</style>

 <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-P6N5G4L');</script>
<!-- End Google Tag Manager -->

<!-- favicon icon -->
<link rel="shortcut icon" href="images/favicon.png" />
<!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
<!-- animate -->
<link rel="stylesheet" type="text/css" href="css/animate.css"/>
<!-- owl-carousel -->
<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
<!-- fontawesome -->
<link rel="stylesheet" type="text/css" href="css/font-awesome.css"/>
<!-- themify -->
<link rel="stylesheet" type="text/css" href="css/themify-icons.css"/>
<!-- flaticon -->
<link rel="stylesheet" type="text/css" href="css/flaticon.css"/>
<!-- REVOLUTION LAYERS STYLES -->
<link rel="stylesheet" type="text/css" href="revolution/css/layers.css">
<link rel="stylesheet" type="text/css" href="revolution/css/settings.css">

<!-- prettyphoto -->
<link rel="stylesheet" type="text/css"             
href="css/prettyPhoto.css">

<!-- shortcodes -->
<link rel="stylesheet" type="text/css" href="css/shortcodes.css"/>

<!-- main -->
<link rel="stylesheet" type="text/css" href="css/main.css"/>

<!-- responsive -->
<link rel="stylesheet" type="text/css" href="css/responsive.css"/></head>

<body>
    
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P6N5G4L"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    
       <!--page start-->
        <!--header start-->
        
     <div class="page">
<header id="masthead" class="header ttm-header-style-classic">
            <!--topbar start-->
            <!--<div class="ttm-topbar-wrapper ttm-bgcolor-skincolor ttm-textcolor-white clearfix bg-white top-header">-->
            <!--    <div class="container">-->
            <!--        <div class="ttm-topbar-content">-->
            <!--            <div class="topbar-right text-left">-->
            <!--                <div class="ttm-social-links-wrapper list-inline" style="padding:0px;">-->
            <!--                    <ul class="social-icons">-->
            <!--                        <li><a href="#" class="fb"><i class="fa fa-facebook"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="tw"><i class="fa fa-twitter"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="pi"><i class="fa fa-pinterest"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="ln"><i class="fa fa-linkedin"></i></a>-->
            <!--                        </li>-->
            <!--                        <li><a href="#" class="in"><i class="fa fa-instagram"></i></a>-->
            <!--                        </li>-->
            <!--                    </ul>-->
            <!--                </div>-->
            <!--                <ul class="top-contact float-right">-->
            <!--                    <a href="#" class="float-left mail-ixon"><i class="fa fa-envelope"></i>&nbsp; info@bambooevents.com</a>-->
            <!--                    <li class="list-inline-item"><strong><a href="tel:+91 99949 24984"><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                 <li class="list-inline-item"><a href="tel:+91 99949 24984"><strong><i class="fa fa-phone"></i></strong> +91 99949 24984</a>-->
            <!--                </li>-->
            <!--                </ul>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            <!--topbar end-->
            <!-- ttm-header-wrap -->
            <div id="ttm-header-wrap">
                <!-- ttm-stickable-header-w -->
                <div id="ttm-stickable-header-w" class="ttm-stickable-header-w ttm-bgcolor-white clearfix bg-transparent">
                    <div id="site-header-menu" class="site-header-menu">
                        <div class="site-header-menu-inner ttm-stickable-header">
                              <div class="container">
                                <div class="site-header-main">
                                    <!-- site-branding -->
                                    <div class="site-branding">
                                        <a class="home-link display-prop" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo-white.png" alt="logo" width="218" height="100">
                                        </a>
                                        <a class="home-link display-prop1" href="index.php" title="planwey" rel="home">
                                            <img id="logo" class="img-center" src="images/logo1.webp" alt="logo" width="218" height="100">
                                        </a>
                                    </div><!-- site-branding end -->
                                    <!--site-navigation -->
                                    <div id="site-navigation" class="site-navigation">
                                        <!-- header-icins -->
                                        <div class="ttm-menu-toggle">
                                            <input type="checkbox" id="menu-toggle-form" />
                                            <label for="menu-toggle-form" class="ttm-menu-toggle-block">
                                                <span class="toggle-block toggle-blocks-1"></span>
                                                <span class="toggle-block toggle-blocks-2"></span>
                                                <span class="toggle-block toggle-blocks-3"></span>
                                            </label>
                                        </div>
                                        <nav id="menu" class="menu">
                                            <ul class="dropdown">
                                                <li class=""><a href="index.php">Home</a></li>
                                                <li class=""><a href="top-event-management-companies.php">About Us</a></li>
                                                <li class="active"><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                                <li class=""><a href="top-event-management-gallery.php">Gallery</a></li>
                                                <li class=""><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                                <li class=""><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                                <li class=""><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                    <!--site-navigation end-->
                                </div>
                            </div>
                        </div>
                    </div><!--ttm-header-wrap end -->
                    
                </div>
            </div><!-- ttm-header-wrap END -->
                    </header>
        <!--header end-->        <!--header end-->        
           <div class="ttm-page-title-row text-center">
            <div class="title-box text-center">
                <div class="container">
                    <div class="page-title-heading">
                        <h1 class="title">Housewarming Event Planners</h1>
                     <!--   <p class="ttm-textcolor-white">We Here You Want A Party?</p> -->
                    </div>
                    <div class="breadcrumb-wrapper">
                        <div class="container">
                            <span><a title="Homepage" href="index.php"><i class="fa fa-home"></i>&nbsp;&nbsp;Home</a></span>
                            <span class="ttm-bread-sep ttm-textcolor-white"> &nbsp; ⁄ &nbsp;</span>
                            <span><a title="Homepage" href="event-managements-services-coimbatore.php"><i class=""></i>&nbsp;&nbsp;Services</a></span>
                            <span class="ttm-bread-sep ttm-textcolor-white"> &nbsp; ⁄ &nbsp;</span>
                            <span class="ttm-textcolor-white"> Housewarming Function</span>
                        </div> 
                    </div>
                </div>  
            </div>
        </div>
        <!--site-main start-->
        <div class="site-main">
            <section class="wide-tb-120 bg-light">
            <div class="container">
                <div class="col-lg-12 text-center">
                            <div class=" section-title clearfix">
                                <h4>END TO END EVENT PLANNERS</h4>
                                <h2 class="title">Housewarming Ceremony Planners</h2>
                                <div class="title-img">
                                    <img src="images/ds-1.webp" alt="housewarming event planners" width="87" height="23">
                                </div>
                            </div>
                        </div>
                <div class="row engage-cont">
                    <div class="col-lg-6 col-md-6">
                        <div class="tab-content detail-img" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-1" role="tabpanel" aria-labelledby="pills-1">
                                <img class="img-fluid" src="images/gallery/houswarming-1.webp" alt="Housewarming Event Planners">
                            </div>
                            <div class="tab-pane fade" id="pills-2" role="tabpanel" aria-labelledby="pills-2">
                                <img class="img-fluid" src="images/gallery/houswarming-2.webp" alt="Housewarming Ceremony Planners">
                            </div>
                            <!--<div class="tab-pane fade" id="pills-3" role="tabpanel" aria-labelledby="pills-3">-->
                            <!--    <img class="img-fluid" src="images/gallery/gallery-8.webp">-->
                            <!--</div>-->
                            <!--<div class="tab-pane fade" id="pills-4" role="tabpanel" aria-labelledby="pills-4">-->
                            <!--    <img class="img-fluid" src="images/gallery/gallery-9.webp"></div>-->
                        </div>
                        <ul class="nav nav-pills mb-3 tumb-img" id="pills-tab" role="tablist">
                            <li class="nav-item">
                              <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-1" role="tab" aria-controls="pills-1" aria-selected="true">
                                  <img class="img-thumbnail" src="images/gallery/houswarming-1-tumbnail.webp" alt="Gruhapravesha Event Organizer" width="100px">
                              </a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-2" role="tab" aria-controls="pills-2" aria-selected="false">
                                  <img class="img-thumbnail" src="images/gallery/houswarming-2-tumbnail.webp" alt="Gruhapravesha Event Planner in Coimbatore" width="100px">
                              </a>
                            </li>
                            <!--<li class="nav-item">-->
                            <!--  <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-3" role="tab" aria-controls="pills-3" aria-selected="false">-->
                            <!--  <img class="img-thumbnail" src="images/gallery/gallery-8.webp" width="100px">-->
                            <!--  </a>-->
                            <!--</li>-->
                            <!--<li class="nav-item">-->
                            <!--  <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-4" role="tab" aria-controls="pills-4" aria-selected="false">-->
                            <!--  <img class="img-thumbnail" src="images/gallery/gallery-9.webp" width="100px">-->
                            <!--  </a>-->
                            <!--</li>-->
                        </ul>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="details-content">
                            <h2>Gruhapravesha Event Organizer</h2>
                           <!--  <h4 class="content-heading">Engagement</h4> -->
                            <p style="text-align:justify">We really do have a dream to construct our own house that is tailored to our expectations. It's time for the housewarming function, which is an announcement that your dream house has been completed and you're ready to share your joy with your family and friends, after the final output, which is after building our dream house. This <a href="top-event-management-companies.php">housewarming function</a> requires detailed process has the potential for all the guests to recall the plans made for the event. We've even received encouragement from the function backpacks, and we've pleased the visitors enough that we've been referred to organise several more <a href="top-event-management-companies.php">housewarming events</a>. We've even received recommendations from the function hosts, and we've impressed the guests enough that we've been referred to organise more and more housewarming events.</p>
                            <div class="details-icons">
                                <!--<a href="#"><i class="fa fa-phone"></i></a>-->
                                <!--<a href="#"><i class="fa fa-whatsapp"></i></a>-->
                                <!--<a href="#"><i class="fa fa-arrow-right"></i></a>-->
                                <!--<a href="#"><i class="fa fa-anchor"></i></a>-->
                                <div class="text-center">
                                <a href="bamboo-event-planner-enquiry.php" class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-30 mb-20">Get a Call Back</a>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </section>
            <section class="ttm-row about-intro-section clearfix">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="ttm-tabs element-tab-style-horizontal width-shape-line clearfix">
                                <!-- tabs -->
                                <ul class="tabs connect-tabs clearfix mb-20">
                                    <li class="tab active"><a href="#">Design and Concept</a></li>
                                    <li class="tab"><a href="#"> Planning and Execution</a></li>
                                    <li class="tab"><a href="#"> Customized Services</a></li>
                                    <li class="tab"><a href="#">Destination We Serve</a></li>
                                </ul>
                                <div class="content-tab">
                                    <div class="content-inner">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-6">
                                                <div class="mb-30">
                                                    <img class="img-fluid" src="images/image8.webp" alt="housewarming ceremony planners">
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <p style="text-align:justify">The housewarming planners make all of the planning from start to finish in order to put together an unforgettable <a href="contact-bamboo-events-coimbatore.php">housewarming ceremony</a>. If you have finished constructing your dream home in and around Coimbatore and Pondicherry, you must first choose an auspicious day for the housewarming function, as well as good timings for the special pooja, before contacting <a href="top-event-management-companies.php">housewarming planners in Coimbatore and Pondicherry</a>. We will immediately respond with a range of creative plans that can be highly customised depending on the function hosters' budget. We'll check the time slots with the best priests available in your region until you confirm that you need our help planning the housewarming events. Additionally, the items used to do the special Pooja must be purchased.</p>
                                        

                                                <div class="row">
                                                  <div class="col-md-12 col-lg-12">
                                                        <!--   <ul class="ttm-list ttm-list-style-icon ttm-list-color-black">
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Aliquam varius sapien non augue imperdiet ultrices.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Etiam in lacus at tortor ultricies ornare.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                              <span class="ttm-list-li-content">Morbi vitae urna vitae nisi aliquam commodo.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                           <span class="ttm-list-li-content">Mauris porttitor nibh non elit tincidunt sollicitudin.</span> 
                                                            </li>
                                                        </ul>  -->
                                                        <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-30 mb-20" href="bamboo-event-planner-enquiry.php" title="">Talk to Our Expert</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="content-inner">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-6">
                                                <p style="text-align:justify">For you to relax and enjoy the moment, a seamless execution of a housewarming celebration requires smooth planning, coordination and execution. We ensure that you do have a delightful, well-organized event free of stress, while also ensuring that everything stays within budget and in line with your vision. The breakfast for the guests is the next most important thing. Since the pooja will be held mainly early in the morning, attendance will be low. However, the breakfast feast will be attended by nearly all of the guests, so the food must be delicious enough to make them feel comfortable. We'll book the <a href="contact-bamboo-events-coimbatore.php">catering service provider</a> for you at an affordable rate depending on the menu you pick. As a result, you can rely on us to provide facilities with utmost precision. As a result, you can make sure that services will be provided with careful attention to detail and exemplify your personal style and taste, giving you the peace of mind to enjoy your housewarming event.</p>
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12">
                                                        <div class="our-services">
                                                          <!--  <ul class="ttm-list ttm-list-style-icon ttm-list-color-black">
                                                                <li>
                                                                    <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                    <span class="ttm-list-li-content">Aliquam varius sapien non augue imperdiet ultrices.</span>
                                                                </li>
                                                                <li>
                                                                    <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                    <span class="ttm-list-li-content">Etiam in lacus at tortor ultricies ornare.</span>
                                                                </li>
                                                                <li>
                                                                    <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                    <span class="ttm-list-li-content">Morbi vitae urna vitae nisi aliquam commodo.</span>
                                                                </li>
                                                                <li>
                                                                    <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                    <span class="ttm-list-li-content">Mauris porttitor nibh non elit tincidunt sollicitudin.</span>
                                                                </li>
                                                            </ul> -->
                                                            <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-30 mb-20" href="bamboo-event-planner-enquiry.php" title="">Talk to Our Expert</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="mb-30">
                                                    <img class="img-fluid" src="images/image7.webp" alt="gruhapravesha event organizer">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="content-inner">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-6">
                                                <div class="image-box mb-30">
                                                    <img class="img-fluid" src="images/image6.webp" alt="house warming event management in coimbatore">
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <p style="text-align:justify">Bamboo Events Planner and Decor does not sell pre-packaged housewarming packages because we agree that no two housewarming packages should ever be the same. Instead, we have a free consultation session during which you can pick from our extensive list of <a href="contact-bamboo-events-coimbatore.php">housewarming planning services</a> such as Priest For Gruhapravesha, Cow and Calf Walk, <a href="top-event-management-companies.php">Caterers</a>, <a href="top-event-management-companies.php">House Decorations & Florists</a>, <a href="top-event-management-companies.php">Photographer</a>, Audio & Lighting, Music Artists, Dancers, Make-up and Hair Stylist, Invitation Cards, Transportation, Accommodation, Balloon Decoration, Popcorn & Candy, Goody Bags/Return Gifts, D.J, Magic Show, Game Show, Orchestra, Welcome Girls, Vegetable Carving, Mahanadi, and Mascot. We build a customised housewarming event proposal that meets your needs and desires based on your budget, taste, vision, and specifications. Almost every Occasion is a celebration of our loved ones to share emotions and joy.</p>
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12">
                                                     <!--    <ul class="ttm-list ttm-list-style-icon ttm-list-color-black">
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Aliquam varius sapien non augue imperdiet ultrices.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Etiam in lacus at tortor ultricies ornare.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Morbi vitae urna vitae nisi aliquam commodo.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Mauris porttitor nibh non elit tincidunt sollicitudin.</span>
                                                            </li>
                                                        </ul> -->
                                                        <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-30 mb-20" href="bamboo-event-planner-enquiry.php" title="">Talk to Our Expert</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="content-inner">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-6">
                                                <p style="text-align:justify">Bamboo Events Planning and Decor has the experience, skills, and quality service that results in <a href="top-event-management-companies.php">housewarming event planning</a> and execution that is pure elegance, style, and sophistication. We promise a stress-free celebration and an utterly grand housewarming ceremony as we have a 100% success rate.
Please contact us by email or phone to schedule a <a href="contact-bamboo-events-coimbatore.php">free housewarming consultation</a> with each of our expert <a href="top-event-management-companies.php">housewarming event planners</a>. We will certainly plan a perfect housewarming function, just as you have imagined and dreamed! We're looking for an opportunity to provide end-to-end <a href="bamboo-event-planner-enquiry.php">event management services</a> to customers in and around Coimbatore, including Avinashi, Karumathampatti, Sulur, Ooty, Coonoor, Mettupalayam, Sathyamangalam, Tirupur, Palladam, Kangeyam Dharapuram, Palani, Kodaikanal, Pollachi, Karur, Erode, Salem, Trichy, Pondicherry, Tamilnadu and Palakkad, Kerala, South India. 
</p>
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-12">
                                                     <!--   <ul class="ttm-list ttm-list-style-icon ttm-list-color-black">
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Aliquam varius sapien non augue imperdiet ultrices.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Etiam in lacus at tortor ultricies ornare.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Morbi vitae urna vitae nisi aliquam commodo.</span>
                                                            </li>
                                                            <li>
                                                                <i class="ti ti-check-box ttm-textcolor-skincolor"></i>
                                                                <span class="ttm-list-li-content">Mauris porttitor nibh non elit tincidunt sollicitudin.</span>
                                                            </li>
                                                        </ul> -->
                                                        <a class="ttm-btn ttm-btn-size-md ttm-btn-shape-round ttm-btn-style-fill ttm-btn-color-skincolor mt-30 mb-20" href="bamboo-event-planner-enquiry.php" title="">Talk to Our Expert</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-6">
                                                <div class="mb-30">
                                                    <img class="img-fluid" src="images/image5.webp" alt="house warming event planner in coimbatore">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="related-product bg-light" style="padding: 40px 0px;">
            <div class="container">
                <h2>Related Product</h2>
                <div class="row owl-carousel owl-theme related-product-bg owl-product">
               <div class="col-12">
                   <div class="event-text">
                    <a href="wedding-planner-coimbatore-india.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Wedding Planner</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="wedding-planner-coimbatore-india.php"><img class="img-fluid" src="images/new/wedding1.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="wedding-planner-coimbatore-india.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Wedding Planner"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="wedding-planner-coimbatore-india.php"><h4 class="text-white" style="margin-bottom:5px;">Wedding Planner</h4></a>-->
                <!--    </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="wedding-planner-coimbatore-india.php"><i class="flaticon flaticon-wedding"></i></a>-->
                <!--</div>   -->
                </div>                 
                </div>
                <div class="col-12">
                     <div class="event-text">
                    <a href="corporate-event-management-companies.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Corporate Events</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="corporate-event-management-companies.php"><img class="img-fluid" src="images/new/corporate1.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="corporate-event-management-companies.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Corporate Events"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="corporate-event-management-companies.php"><h4 class="text-white" style="margin-bottom:5px;">Corporate Events</h4></a>-->
                <!--        </div> -->
                <!--        <div class="icon-links">-->
                <!--<a href="corporate-event-management-companies.php"><i class="flaticon flaticon-cheers"></i></a>-->
                <!--</div>                  -->
                </div>                 
                </div>
                <div class="col-12">
                     <div class="event-text">
                    <a href="birthday-party-event-management.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Birthday Party</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="birthday-party-event-management.php"><img class="img-fluid" src="images/new/birthday1.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="birthday-party-event-management.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Birthday Party"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="birthday-party-event-management.php"><h4 class="text-white" style="margin-bottom:5px;">Birthday Party</h4></a>-->
                <!--        </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="birthday-party-event-management.php"><i class="flaticon flaticon-cake"></i></a>-->
                <!--</div>                 -->
                </div>                 
                </div> 
                <div class="col-12">
                     <div class="event-text">
                    <a href="housewarmig-functions-organizer.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Housewarming</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="housewarmig-functions-organizer.php"><img class="img-fluid" src="images/house-warming.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="housewarmig-functions-organizer.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Housewarming"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="housewarmig-functions-organizer.php"><h4 class="text-white" style="margin-bottom:5px;">Housewarming</h4></a>-->
                <!--        </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="housewarmig-functions-organizer.php"><i class="flaticon flaticon-pooja"></i></a>-->
                <!--</div>                 -->
                </div>                 
                </div>
                <div class="col-12">
                     <div class="event-text">
                    <a href="puberty-event-function-organizer.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Puberty Function</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="puberty-event-function-organizer.php"><img class="img-fluid" src="images/puberty-function.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="puberty-event-function-organizer.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Puberty Function"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="puberty-event-function-organizer.php"><h4 class="text-white" style="margin-bottom:5px;">Puberty Function</h4></a>-->
                <!--        </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="puberty-event-function-organizer.php"><i class="flaticon flaticon-hairdresser"></i></a>-->
                <!--</div>                 -->
                </div>                 
                </div>
                <div class="col-12">
                     <div class="event-text">
                    <a href="engagement-planner-coimbatore.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Engagement</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="engagement-planner-coimbatore.php"><img class="img-fluid" src="images/engagement.webp"></a>
                    <div class="actions">
                        <div class="ul-action-link"><a href="engagement-planner-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Engagement"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="engagement-planner-coimbatore.php"><h4 class="text-white" style="margin-bottom:5px;">Engagement</h4></a>-->
                <!--        </div>-->
                <!--    <div class="icon-links">-->
                <!--        <a href="engagement-planner-coimbatore.php"><i class="flaticon flaticon-rings"></i></a>-->
                <!--</div>  -->
                </div>                 
                </div>                 
                <div class="col-12">
                     <div class="event-text">
                    <a href="wedding-anniversary-event-planner.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Anniversary</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="wedding-anniversary-event-planner.php"><img class="img-fluid" src="images/categories_1.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="wedding-anniversary-event-planner.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Engagement"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="wedding-anniversary-event-planner.php"><h4 class="text-white" style="margin-bottom:5px;">Anniversary</h4></a>-->
                <!--        </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="wedding-anniversary-event-planner.php"><i class="flaticon flaticon-wedding-couple"></i></a>-->
                <!--</div> -->
                </div>                 
                </div>
                <div class="col-12">
                     <div class="event-text">
                    <a href="exhibition-stall-design-fabricators-services.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Exhibition Stall</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="exhibition-stall-design-fabricators-services.php"><img class="img-fluid" src="images/stall10.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="exhibition-stall-design-fabricators-services.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Exhibition Stall"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="exhibition-stall-design-fabricators-services.php"><h4 class="text-white" style="margin-bottom:5px;">Exhibition Stall</h4></a>-->
                <!--        </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="exhibition-stall-design-fabricators-services.php"><i class="flaticon flaticon-exhibition"></i></a>-->
                <!--</div>  -->
                </div>                 
                </div>
                <div class="col-12">
                     <div class="event-text">
                    <a href="school-college-alumni-event-planners.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Alumni Meets</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="school-college-alumni-event-planners.php"><img class="img-fluid" src="images/alumini-meet.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="school-college-alumni-event-planners.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="College/School Alumni"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="school-college-alumni-event-planners.php"><h4 class="text-white" style="margin-bottom:5px;">Alumni Meets</h4></a>-->
                <!--        </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="school-college-alumni-event-planners.php"><i class="flaticon flaticon-graduated"></i></a>-->
                <!--</div>    -->
                </div>                 
                </div>

                <div class="col-12">
                     <div class="event-text">
                    <a href="bangle-ceremony-event-valaikappu-function.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Bangle Ceremony</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="bangle-ceremony-event-valaikappu-function.php"><img class="img-fluid" src="images/bangle-ceramony.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="bangle-ceremony-event-valaikappu-function.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Bangle Ceremony"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="bangle-ceremony-event-valaikappu-function.php"><h4 class="text-white" style="margin-bottom:5px;">Bangle Ceremony</h4></a>-->
                <!--        </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="bangle-ceremony-event-valaikappu-function.php"><i class="flaticon flaticon-pregnant"></i></a>-->
                <!--</div>   -->
                </div>                 
                </div>
                <div class="col-12">
                     <div class="event-text">
                    <a href="sangeet-mehendi-ceremony-coimbatore.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Sangeet & Mehendi</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="sangeet-mehendi-ceremony-coimbatore.php"><img class="img-fluid" src="images/sangeet-mehandi.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="sangeet-mehendi-ceremony-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Sangeet & Mehendi"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="sangeet-mehendi-ceremony-coimbatore.php"><h4 class="text-white" style="margin-bottom:5px;">Sangeet & Mehendi</h4></a>-->
                <!--        </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="sangeet-mehendi-ceremony-coimbatore.php"><i class="flaticon flaticon-mehndi"></i></a>-->
                <!--</div>    -->
                </div>                 
                </div>
                <div class="col-12">
                     <div class="event-text">
                    <a href="baby-naming-ceremony-events.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Baby Naming Ceremony</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="baby-naming-ceremony-events.php"><img class="img-fluid" src="images/baby-naming-caremony.webp"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="baby-naming-ceremony-events.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Baby Naming Ceremony"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                <!--    <div class="event-name">-->
                <!--        <a href="baby-naming-ceremony-events.php"><h4 class="text-white" style="margin-bottom:5px;">Baby Naming Ceremony</h4></a>-->
                <!--        </div>-->
                <!--        <div class="icon-links">-->
                <!--<a href="baby-naming-ceremony-events.php"><i class="flaticon flaticon-crib"></i></a>-->
                <!--</div>   -->
                </div>                 
                </div>    
                
                
                <div class="col-12">
                     <div class="event-text">
                    <a href="top-best-destination-wedding-planners.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Destination Wedding</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="top-best-destination-wedding-planners.php"><img class="img-fluid" src="images/destination-wedding-planner.jpg" alt="Destination Wedding Planner" title="Destination Wedding Planner"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="top-best-destination-wedding-planners.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Destination Wedding Planner"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                </div>                 
                </div>
                
                <div class="col-12">
                     <div class="event-text">
                    <a href="product-launch-event-organizers-chennai.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Product Launch Event</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="product-launch-event-organizers-chennai.php"><img class="img-fluid" src="images/product-launch-events.jpg" alt="Product Launch Event" title="Product Launch Event" ></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="product-launch-event-organizers-chennai.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Product Launch Event"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                </div>                 
                </div>
                
                <div class="col-12">
                     <div class="event-text">
                    <a href="company-award-ceremony-event-planner.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Award Ceremonies Planner</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="company-award-ceremony-event-planner.php"><img class="img-fluid" src="images/award-ceremony-events.jpg" alt="Award Ceremonies Planner" title="Award Ceremonies Planner"></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="company-award-ceremony-event-planner.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Award Ceremonies Planner"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                </div>                 
                </div>
                
                <div class="col-12">
                     <div class="event-text">
                    <a href="corporate-social-event-planner-india.php"><h4 class="text-center" style="margin-bottom:5px; font-family: cursive;">Corporate Social Events</h4></a>
                    </div>
                    <div class="zoom-img">
                        <a href="corporate-social-event-planner-india.php"><img class="img-fluid" src="images/corporate-social-events.jpg" alt="Corporate Social Events" title="Corporate Social Events" ></a>
                    <div class="actions">
                    <div class="ul-action-link"><a href="corporate-social-event-planner-india.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Corporate Social Events"></a></div>
                    <div class="ul-call-us"><a href="tel:+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Call Us"></a></div>
                    <div class="ul-whats-app"><a href="https://api.WhatsApp.com/send?phone=+91 99949 24984" data-toggle="tooltip" data-placement="right" title="" data-original-title="Whats app"></a></div>
                    <div class="ul-contact-us"><a href="contact-bamboo-events-coimbatore.php" data-toggle="tooltip" data-placement="right" title="" data-original-title="Contact Us"></a></div>
                    </div>
                </div>                 
                </div>
                
                
                
                
                
                
                
                
                </div>             
            </div>
        </section>        </div>
        <!--footer--> 
        <footer class="footer widget-footer bg-img11 ttm-bgcolor-black ttm-bg ttm-bgimage-yes clearfix">
            <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
            <div class="second-footer">
                <div class="container">
                    <div class="second-footer-inner">
                        <div class="row">
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">Quick Links </h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="top-event-management-companies.php">Why Us</a></li>
                                        <li><a href="event-managements-services-coimbatore.php">What We Do</a></li>
                                        <li><a href="top-event-management-gallery.php">Gallery</a></li>
                                        <li><a href="bamboo-event-planner-faq.php">FAQ</a></li>
                                        <li><a href="bamboo-event-planner-enquiry.php">Enquiry</a></li>
                                        <li><a href="contact-bamboo-events-coimbatore.php">Contact Us</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget_nav_menu clearfix">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="engagement-planner-coimbatore.php">Engagement</a></li>
                                        <li><a href="wedding-planner-coimbatore-india.php">Wedding Planner</a></li>
                                        <li><a href="top-best-destination-wedding-planners.php">Destination Wedding</a></li>
                                        <li><a href="corporate-event-management-companies.php">Corporate Events</a></li>
                                        <li><a href="product-launch-event-organizers-chennai.php">Product Launch Events</a></li>
                                        <li><a href="company-award-ceremony-event-planner.php">Company Award Ceremony</a></li>
                                        <li><a href="virtual-online-event-management-organizers.php">Virtual Event Planner</a></li>
                                        <li><a href="corporate-social-event-planner-india.php">Corporate Social Events</a></li>
                                        <li><a href="exhibition-stall-design-fabricators-services.php">Exhibition Stall</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix ">
                                    <h4 class="widget-title">What We Do</h4>
                                    <ul class="menu-footer-services">
                                        <li><a href="birthday-party-event-management.php">Birthday Party</a></li>
                                        <li><a href="housewarmig-functions-organizer.php">Housewarming</a></li>
                                        <li><a href="baby-naming-ceremony-events.php">Baby Naming Ceremony</a></li>
                                        <li><a href="puberty-event-function-organizer.php">Puberty Function</a></li>
                                        <li><a href="bangle-ceremony-event-valaikappu-function.php">Bangle Ceremony</a></li>
                                        <li><a href="sangeet-mehendi-ceremony-coimbatore.php">Sangeet & Mehendi</a></li>
                                        <li><a href="wedding-anniversary-event-planner.php">Anniversary</a></li>
                                        <li><a href="school-college-alumni-event-planners.php">College/School Alumni</a></li>
                                    </ul>
                                    <!--<h4 class="widget-title">Frequent Questions</h4>
                                    <ul class="widget-text">
                                        <li><a href="#">How Can I Set An Event? </a></li>
                                        <li><a href="#">What Venues Do You Use? </a></li>
                                        <li><a href="#">Event Catalogue </a></li>
                                        <li><a href="#">Shipping & Delivery </a></li>
                                        <li><a href="#">What's your dream job? </a></li>
                                    </ul>-->
                                </div>
                            </div>
                            <div class="widget-area col-xs-12 col-sm-6 col-md-6 col-lg-3">
                                <div class="widget widget-out-link clearfix">
                                    <h4 class="widget-title">Contact Us</h4>
                                    <ul class="widget-contact">
                                        <!--<li><i class="fa fa-map-marker"></i>No.45A, Kalluri Nagar,<br>Near Peelamedu Fire Station,<br>Periyar Nagar,<br>Masakalipalayam,<br>Peelamedu,<br>Coimbatore-641004.</li>-->
                                        <li><i class="fa fa-map-marker"></i>No.2, Ground floor,<br>D.J.Nagar,Hopescollage,<br>Near Water Tank,<br>Coimbatore-641 004.</li>
                                        <li><i class="fa fa-envelope-o"></i><a href="mailto:enquiry@bambooevents.co.in">enquiry@bambooevents.co.in</a></li>
                                        <li><a href="tel:+919994924984"><i class="fa fa-phone"></i>+91 99949 24984</li></a>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom-footer-text">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-sm-12 col-xs-12 ttm-footer2-left">
                            <div class="company-info" style="color: #fff;">
                                  <P>Copyright © 2023 <span style="color: #b4cd29;">Bamboo Events Planning &amp; Decor</span>. All Rights Reserved. Designed By <a href="https://www.xcodefix.com/"target="_blank">Xcodefix</a></P>
                            </div>
                        </div>
                        <div class="col-sm-12 col-xs-12 col-md-4 ttm-footer2-right">
                            <div class="ttm-social-link-wrapper list-inline" style="padding:2px;">
                                <ul class="social-icons">
                                    <ul class="social-icons">
                                    <li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li><a href="https://www.instagram.com/bambooevents_cbe/" class="in"><i class="fa fa-instagram"></i></a>
                                    </li>
                                    <li><a href="https://twitter.com/BambooDecors" class="tw"><i class="fa fa-twitter"></i></a>
                                    </li>
                                    <li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" class="ln"><i class="fa fa-youtube-play"></i></a>
                                    </li>
                                    
                                </ul>
                                    <!--<li><a href="https://www.facebook.com/bambooeventsindia/" class="fb" target="_blank"><i class="fa fa-facebook"></i></a></li>-->
                                    <!--<li><a href="https://twitter.com/BambooDecors" target="_blank"><i class="fa fa-twitter"></i></a></li>-->
                                    <!--<li><a href="https://www.instagram.com/bambooevents_cbe/" target="_blank"><i class="fa fa-instagram"></i></a></li>-->
                                    <!--<li><a href="https://www.youtube.com/channel/UCxyMUWvPL_BckC8V-iGA_ig" target="_blank"><i class="fa fa-youtube-play"></i></a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
</div>       <div class="side-icons">
    <div class="inner-side-icon">
        <a href="https://wa.me/+919994924984?text=I'm%20interested%20in%20your%20Bamboo%20Events%20Services" target="_blank"><i class="fa fa-whatsapp" style="font-size: 48px;"></i></a> 
    </div>
    <div class="inner-side-icon">
        <a href="tel:+919994924984"><i class="fa fa-phone" style="font-size: 48px;"></i></a>
    </div>
</div>        <!--footer-END-->
    <!--back-to-top start-->
    <a id="totop" href="#top">
        <i class="fa fa-angle-up"></i>
    </a>
    <!--back-to-top end-->



    <!-- Javascript -->

    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script> 
    <script src="js/jquery.easing.js"></script>    
    <script src="js/jquery-waypoints.js"></script>    
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/numinate.min6959.js?ver=4.9.3"></script>
    <script src="js/main.js"></script>


    <!-- Revolution Slider -->
    <script src="revolution/js/jquery.themepunch.tools.min.js"></script>
    <script src="revolution/js/jquery.themepunch.revolution.min.js"></script>
    <script src="revolution/js/slider.js"></script>

    <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->    

    <script src="revolution/js/extensions/revolution.extension.actions.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.carousel.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.migration.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.navigation.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.parallax.min.js"></script>
    <script src="revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
    <!-- Javascript end-->

</body>

<!-- Mirrored from themetechmount.com/html/planwey/header-elegant.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 12 Mar 2021 05:45:30 GMT -->
</html>